package Models;

import javax.inject.*;
import java.util.Set;
import java.util.HashSet;
import org.jongo.MongoCollection;
import org.jongo.MongoCursor;
import uk.co.panaxiom.playjongo.*;

@Singleton
public class TimeHoleRepository{

//------------------------------------------------------------------
// Deklarationen
//------------------------------------------------------------------

    @Inject
    private PlayJongo m_dbConnection;
    private static TimeHoleRepository instance = null;

//------------------------------------------------------------------
// Properties
//------------------------------------------------------------------

    // Get Singleton Instanz
    public static TimeHoleRepository getInstance(){
        return instance;
    }

    // Get TimeHole-Datenbank
    public MongoCollection getDatenBank(){
        MongoCollection mc = m_dbConnection.getCollection("timeholes");
        return mc;
    }

    // Get TimeHole mithilfe des Namens
    public TimeHole getTimeHoleByName(String pi_name){
        return getDatenBank().findOne("{_id: #}", pi_name).as(TimeHole.class);
    }

    // Get alle TimeHoles als Set
    public HashSet<TimeHole> getAllTimeHoles(){
        HashSet<TimeHole> result = new HashSet<TimeHole>();
        MongoCursor<TimeHole> th = getDatenBank().find().as(TimeHole.class);
        // Füge alle TimeHole dem Set hinzu
        while(th.hasNext()){
            result.add(th.next());
        }
        // Gebe alle TimeHoles zurück
        return result;
    }

    // Get alle aktiven TimeHoles als Set
    public HashSet<Global.Location> getTimeHoles(){
        HashSet<Global.Location> locations = new HashSet<Global.Location>();
        for(TimeHole timeHole : getAllTimeHoles())
            if(timeHole.getActive())
                locations.add(timeHole.getLocation());
        return locations;
    }

//------------------------------------------------------------------
// Methoden
//------------------------------------------------------------------

    // TimeHole in DB speichern
    public void saveTimeHole(TimeHole pi_TH){
        if(getTimeHoleByName(pi_TH.getName()) == null)
            getDatenBank().save(pi_TH);
    }

    // Update TimeHole in DB
    public void updateTimeHole(TimeHole pi_TH){
        getDatenBank().update("{_id: #}", pi_TH.getName()).with("#", pi_TH);
    }

//------------------------------------------------------------------
// Konstruktoren
//------------------------------------------------------------------

    // Singleton Konstruktor
    public TimeHoleRepository() {
        instance = this;
    }

    // Fügt vordefiniertes Set in Datenbank ein
    public void Init(){
        // Location von Fakultät für Mathematik und Informatik
        saveTimeHole(new TimeHole("FMI",                new Global.Location(48.262765, 11.668268)));
        // Location von Interimshörsaal
        saveTimeHole(new TimeHole("Interimshörsaal",    new Global.Location(48.263607, 11.669266)));
        // Location von Fakultät Maschinenwesen Hörsaal 1
        saveTimeHole(new TimeHole("MW0001",             new Global.Location(48.265438, 11.670956)));
        // Location See hinter dem MW Gebäude
        saveTimeHole(new TimeHole("MW StudentCafe",     new Global.Location(48.264985, 11.666907)));
        // Location für Physik Fakultät
        saveTimeHole(new TimeHole("Physik",             new Global.Location(48.267271, 11.675811)));
        // Location für U-Bahn Haltestelle
        saveTimeHole(new TimeHole("U6 Station",         new Global.Location(48.265336, 11.671584)));
        // Location für Innenstadt Campus
        saveTimeHole(new TimeHole("Innenstadt Campus",  new Global.Location(48.149388, 11.5660578)));
    }
}