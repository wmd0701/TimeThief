package Models;

import javax.inject.*;
import java.util.Set;
import java.util.HashSet;
import org.jongo.MongoCollection;
import org.jongo.MongoCursor;
import uk.co.panaxiom.playjongo.*;

@Singleton
public class UserDatenRepository{

//------------------------------------------------------------------
// Deklarationen
//------------------------------------------------------------------

    @Inject
    private PlayJongo m_dbConnection;
    private static UserDatenRepository instance = null;

//------------------------------------------------------------------
// Properties
//------------------------------------------------------------------

    // Get Singleton
    public static UserDatenRepository getInstance(){
        return instance;
    }

    // Get User-Datenbank
    public MongoCollection getUsers(){
        MongoCollection mc = m_dbConnection.getCollection("users");
        return mc;
    }

    // User mithilfe der FirebaseID holen
    public UserDaten getUserByID(String pi_sID){
        return getUsers().findOne("{_id: #}", pi_sID).as(UserDaten.class);
    }

    // User mithilfe des Nicknames holen
    public UserDaten getUserByNickname(String pi_sNickname){
        // Gesuchter Nickname darf nicht leer sein
        if(pi_sNickname != null && pi_sNickname != ""){
            return getUsers().findOne("{m_sNickname: #}", pi_sNickname).as(UserDaten.class);
        }
        else{
            return null;
        }
    }

    // Alle User als Set holen
    public HashSet<UserDaten> getAllUsers(){
        HashSet<UserDaten> result = new HashSet<UserDaten>();
        MongoCursor<UserDaten> ud = getUsers().find().as(UserDaten.class);
        // Füge alle Nutzer dem Set hinzu
        while(ud.hasNext()){
            result.add(ud.next());
        }
        // Gebe alle Nutzer zurück
        return result;
    }

//------------------------------------------------------------------
// Methoden
//------------------------------------------------------------------

    // User in DB speichern
    public void saveUser(UserDaten pi_UD){
        getUsers().save(pi_UD);
    }

    // User in DB updaten
    public void updateUser(UserDaten pi_UD){
        getUsers().update("{_id: #}", pi_UD.getFirebaseID()).with("#", pi_UD);
    }

//------------------------------------------------------------------
// Konstruktoren
//------------------------------------------------------------------

    // Singleton Konstruktor
    public UserDatenRepository() {
        instance = this;
    }
}