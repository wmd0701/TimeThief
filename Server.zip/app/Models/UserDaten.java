package Models;

import java.util.HashSet;
import com.fasterxml.jackson.annotation.JsonProperty;

public class UserDaten{

//------------------------------------------------------------------
// Deklarationen
//------------------------------------------------------------------

    @JsonProperty("_id")
    private String m_sFirebaseID;
    private String m_sFirebaseToken;
    private long m_iTimeToLive;
    private long m_iSurvived;
    private boolean m_fActive;
    private boolean m_fStolen;
    private String m_sNickname;
    private Global.Location m_Location;
    private HashSet<String> m_lsFriends;
    private HashSet<String> m_lsRequestedFriends;

//------------------------------------------------------------------
// Properties
//------------------------------------------------------------------

    // Get FirebaseID
    public String getFirebaseID(){
        return m_sFirebaseID;
    }

    // Set FirebaseID
    public void setFirebaseID(String pi_sID){
        m_sFirebaseID = pi_sID;                
        // Update in der Datenbank
        UserDatenRepository.getInstance().updateUser(MyCopy());
    }

    // Get Firebase Token
    public String getFirebaseToken(){
        return m_sFirebaseToken;
    }

    // Set Firebase Token
    public void setFirebaseToken(String pi_sToken){
        m_sFirebaseToken = pi_sToken;        
        // Update in der Datenbank
        UserDatenRepository.getInstance().updateUser(MyCopy());
    }

    // Get übrige Zeit
    public long getTimeToLive(){
        return m_iTimeToLive;
    }

    // Set übrige Zeit
    public void setTimeToLive(long pi_iTime){
        // Zeit darf niemals negativ werden
        m_iTimeToLive = pi_iTime > 0 ? pi_iTime : 0;
        // Update in der Datenbank
        UserDatenRepository.getInstance().updateUser(MyCopy());
    }

    // Get überlebte Zeit
    public long getSurvived(){
        return m_iSurvived;
    }

    // Set überlebte Zeit
    public void setSurvived(long pi_iTime){
        m_iSurvived = pi_iTime;
        // Update in der Datenbank
        UserDatenRepository.getInstance().updateUser(MyCopy());
    }

    // Get ob Nutzer online ist
    public boolean getActive(){
        return m_fActive;
    }

    // Get ob Nutzer zur Zeit gestohlen ist
    public boolean getStolen(){
        return m_fStolen;
    }

    // Set ob Nutzer online ist
    public void setActive(boolean pi_fActive){
        m_fActive = pi_fActive;    
        // Update in der Datenbank
        UserDatenRepository.getInstance().updateUser(MyCopy());
    }

    // Set ob Nutzer zur Zeit gestohlen ist
    public void setStolen(boolean pi_fStolen){
        m_fStolen = pi_fStolen;
        // Update in der Datenbank
        UserDatenRepository.getInstance().updateUser(MyCopy());
    }

    // Get einzigartigen Nickname des Nutzers
    public String getNickname(){        
        if(m_sNickname != null)
            return m_sNickname;
        else
            // Der einzige verbotene Nickname ist der leere String!
            return "";
    }

    // Set Nickname (falls noch nicht vergeben)
    public boolean setNickname(String pi_sNickname){
        // Nickname nicht nichts und noch nicht vergeben?
        if(pi_sNickname != "" && pi_sNickname != null && 
            (UserDatenRepository.getInstance().getUserByNickname(pi_sNickname) == null)){
            // Update alle Nutzer die mit diesem User befreundet sind
            HashSet<UserDaten> all = UserDatenRepository.getInstance().getAllUsers();
            HashSet<UserDaten> wasFriend = new HashSet<UserDaten>();
            // Loope alle User
            for(UserDaten u : all){
                // Falls befreundet entferne alten Nickname und füge zur Liste hinzu
                if(u.getFriends().contains(m_sNickname)){
                    u.removeFriend(m_sNickname);
                    wasFriend.add(u);
                }
            }
            // Dann ändere den Nickname                
            m_sNickname = pi_sNickname;
            // Update in der Datenbank
            UserDatenRepository.getInstance().updateUser(MyCopy());
            // Loope alle Befreundeten und füge selbst wieder hinzu
            for(UserDaten u : wasFriend){
                u.addFriend(m_sNickname);
            }
            // Wechsel erfolgreich
            return true;
        }
        else{
            return false;
        }
    }

    // Get aktuellste Position (set über update)
    public Global.Location getLocation(){
        return m_Location;
    }

    // Get Freundesliste (set über add/remove Funktionen)
    public HashSet<String> getFriends(){
        return m_lsFriends;
    }

    // Get Liste der Anfragen
    public HashSet<String> getRequestedFriends(){
        return m_lsRequestedFriends;
    }


//------------------------------------------------------------------
// Methoden
//------------------------------------------------------------------

    // Setzt den User auf aktiv
    public void login(){
        setActive(true);
    }

    // Logout nur möglich wenn nicht von ihm gestohlen wird
    public void logout(){
        setActive(false);
        // Leere die Anfrageliste bei Logout
        clearRequests();
    }

    // Aktualisiert Position
    public void updateLocation(double pi_dLongitude, double pi_dLatitude){
        m_Location.Longitude = pi_dLongitude;
        m_Location.Latitude = pi_dLatitude;
        // Update in der Datenbank
        UserDatenRepository.getInstance().updateUser(MyCopy());
    }

    // Fügt Freund hinzu
    public void addFriend(String pi_sNickname){
        // Füge hinzu falls der User aktuell existiert
        if(UserDatenRepository.getInstance().getUserByNickname(pi_sNickname) != null){
            m_lsFriends.add(pi_sNickname);
            // Update in der Datenbank
            UserDatenRepository.getInstance().updateUser(MyCopy());
        }
    }

    // Entferne Freund
    public void removeFriend(String pi_sNickname){
        // Entferne falls der User aktuell existiert
        if(UserDatenRepository.getInstance().getUserByNickname(pi_sNickname) != null){
            m_lsFriends.remove(pi_sNickname);
            // Update in der Datenbank
            UserDatenRepository.getInstance().updateUser(MyCopy());
        }
    }

    // Speichere Freundschaftsanfrage
    public void requestFriend(String pi_sNickname){
        // Füge hinzu falls der User aktuell existiert
        if(UserDatenRepository.getInstance().getUserByNickname(pi_sNickname) != null){
            m_lsRequestedFriends.add(pi_sNickname);
            // Update in der Datenbank
            UserDatenRepository.getInstance().updateUser(MyCopy());
        }
    }

    // Leert die Anfrageliste
    private void clearRequests(){
        m_lsRequestedFriends.clear();
        // Update in der Datenbank
        UserDatenRepository.getInstance().updateUser(MyCopy());
    }

//------------------------------------------------------------------
// Konstruktoren
//------------------------------------------------------------------

    // Leerer Konstruktor
    private UserDaten(){}

    // Konstruktor mit ID 
    public UserDaten(String pi_sFirebaseID){
        // Macht nichts falls User bereits existiert
        if(UserDatenRepository.getInstance().getUserByID(pi_sFirebaseID) == null){
            m_sFirebaseID = pi_sFirebaseID;
            m_sFirebaseToken = "";
            m_iTimeToLive = Global.STANDARTTIME;
            m_iSurvived = 0;
            m_fActive = true;
            m_fStolen = false;
            m_sNickname = "";
            m_Location = new Global.Location();
            m_lsFriends = new HashSet<String>();
            m_lsRequestedFriends = new HashSet<String>();
        }
    }

    // Copy Konstruktor
    private UserDaten(String pi_sFirebaseID, String pi_sFirebaseToken, long pi_iTimeToLive, long pi_iSurvived,
                      boolean pi_fActive, boolean pi_fStolen, String pi_sNickname, Global.Location pi_Location,
                      HashSet<String> pi_lsFriends, HashSet<String> pi_lsRequestedFriends){
        m_sFirebaseID = pi_sFirebaseID;
        m_sFirebaseToken = pi_sFirebaseToken;
        m_iTimeToLive = pi_iTimeToLive;
        m_iSurvived = pi_iSurvived;
        m_fActive = pi_fActive;
        m_fStolen = pi_fStolen;
        m_sNickname = pi_sNickname;
        m_Location = pi_Location;
        m_lsFriends = pi_lsFriends;
        m_lsRequestedFriends = pi_lsRequestedFriends;
    }

    // Erstellt Kopie von eigenen Daten
    private UserDaten MyCopy(){
        return new UserDaten
        (
            m_sFirebaseID,
            m_sFirebaseToken,
            m_iTimeToLive,
            m_iSurvived,
            m_fActive,
            m_fStolen,
            m_sNickname,
            m_Location,
            m_lsFriends,
            m_lsRequestedFriends
        );
    }
}