package Models;

import java.util.HashSet;
import com.fasterxml.jackson.annotation.JsonProperty;

public class TimeHole{

//------------------------------------------------------------------
// Deklarationen
//------------------------------------------------------------------

    @JsonProperty("_id")
    private String name;
    private Global.Location location;
    private boolean active;

//------------------------------------------------------------------
// Properties
//------------------------------------------------------------------

    // Get name
    public String getName(){
        return name;
    }

    // Get location
    public Global.Location getLocation(){ 
        return location;
    }

    // Get active
    public boolean getActive(){
        return active;
    }

    // Set active
    public void setActive(boolean active){
        this.active = active;
        // Update in der Datenbank
        TimeHoleRepository.getInstance().updateTimeHole(MyCopy());
    }

//------------------------------------------------------------------
// Konstruktoren
//------------------------------------------------------------------
    // Leerer Konstruktor
    public TimeHole(){}

    // Konstruktor mit Name und Location
    public TimeHole(String name, Global.Location location){
        this.name = name;
        this.location = location;
        this.active = true;
    }

    // Konstruktor mit Name, Location und Active
    public TimeHole(String name, Global.Location location, boolean active){
        this.name = name;
        this.location = location;
        this.active = active;
    }

    // Erstellt Kopie von eigenen Daten
    private TimeHole MyCopy(){
        return new TimeHole(name, location, active);
    }
}