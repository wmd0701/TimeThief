package Models;

import java.time.*;
import java.util.*;

// Enthält alle Konstanten etc.
public class Global{

    //region Konstanten

    // Jeder Spieler startet mit dieser Zeit (4h in sec)
    public static long STANDARTTIME = 14440;
    // Faktor für gestohlene Zeit
    public static double STEALFACTOR = 10;
    // Radius in dem Zeit geteilt werden darf
    public static double SHARERADIUS = 100;
    // Radius in dem gestohlen werden kann
    public static double STEALRADIUS = 100;
    // Erdradius in Metern
    public static double ER = 6371000;
    // Faktor für TimeHole Aufladen
    public static double CHARGEFACTOR = 10;
    // Radius der TimeHoles
    public static double CHARGERADIUS = 100;
    // Bufferzeit der CM für Angriffe
    public static int MESSAGEDURATION = 10;
    // Boolean als String
    public static String TRUE = "true";
    public static String FALSE = "false";

    //endregion

    //region Helper Structs

    // "Struct" für Positionen
    public static class Location {
        public double Longitude;
        public double Latitude;
        
        // Erstellt einen String der zugleich ein gültiges JSON-Objekt ist
        @Override
        public String toString(){
            return "{Longitude:" + Longitude + ",Latitude:" + Latitude + "}";
        }

        // Leerer Konstruktor
        public Location(){}

        // Konstruktor mit Parameter
        public Location(double Longitude, double Latitude){
            this.Longitude = Longitude;
            this.Latitude = Latitude;
        }

        // überschreiben equals und hashCode Methoden, um Location in Collection zu speichern
        @Override
        public boolean equals(Object o){
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            Location l = (Location) o;
            return Longitude == l.Longitude && Latitude == l.Latitude;
        }

        @Override
        public int hashCode(){
            return Objects.hash(Longitude, Latitude);
        }

    }

    // "Struct" für Zeit stehlen
    public static class StealingState{
        private LocalDateTime m_dtStart;        
        
        // Stehlen abgeschlossen (erfolgreich ja/nein)
        public int getStolenTime(){
            // Bestimme Zeit basierend auf dem Stehlenfaktor und gebe zurück
            return (int) ((Duration.between(m_dtStart, LocalDateTime.now()).toMillis() * STEALFACTOR) / 1000);
        }

        // Konstruktor speichert Erstellzeitpunkt
        public StealingState(){
            m_dtStart = LocalDateTime.now();            
        }
    }

    //endregion

    //region Utility Funktionen

    // Erstellt JSON Objekt für eine HashMap
    public static <K, V> String TableToJSON(Map<K, V> input) {
        String result = "";
		for (Map.Entry<K, V> k : input.entrySet()) {
			result += "," + k.getKey().toString() + ":" + k.getValue().toString();
        }
        // Kann auch leer sein!
		result = "{" + (result.length() > 0 ? result.substring(1) : "") + "}";
		return result;
	}
    
    // Erstellt JSON Objekt für eine Collection
	public static <K> String CollectionToJSON(Collection<K> input) {
        String result = "";        
		for (K k : input) {
			result += "," + k.toString();
        }
        // Kann auch leer sein!
		result = "[" + (result.length() > 0 ? result.substring(1) : "") + "]";
		return result;
	}

    // Bestimmt Distanz zwischen zwei Positionen in m
    public static double getDistanceBetween(UserDaten pi_U1, UserDaten pi_U2) {
        // Bestimme Differenz
        double dLat = Deg2Rad(pi_U2.getLocation().Latitude-pi_U1.getLocation().Latitude);
        double dLon = Deg2Rad(pi_U2.getLocation().Longitude-pi_U1.getLocation().Longitude);        
        // Haversine Formel
        double dA = 
            Math.sin(dLat/2) * Math.sin(dLat/2) +
            Math.cos(Deg2Rad(pi_U1.getLocation().Latitude)) * Math.cos(Deg2Rad(pi_U2.getLocation().Latitude)) * 
            Math.sin(dLon/2) * Math.sin(dLon/2);
        double dC = 2 * Math.atan2(Math.sqrt(dA), Math.sqrt(1-dA)); 
        // Gebe diese zurück
        return (ER * dC);
    }

    // getDistanceBetween zwischen Benutzer und TimeHole
    public static double getDistanceBetween(UserDaten pi_U, Location l) {
        // Bestimme Differenz
        double dLat = Deg2Rad(l.Latitude-pi_U.getLocation().Latitude);
        double dLon = Deg2Rad(l.Longitude-pi_U.getLocation().Longitude);
        // Haversine Formel
        double dA =
                Math.sin(dLat/2) * Math.sin(dLat/2) +
                Math.cos(Deg2Rad(pi_U.getLocation().Latitude)) * Math.cos(Deg2Rad(l.Latitude)) *
                Math.sin(dLon/2) * Math.sin(dLon/2);
        double dC = 2 * Math.atan2(Math.sqrt(dA), Math.sqrt(1-dA));
        // Gebe diese zurück
        return (ER * dC);
    }
      
    private static double Deg2Rad(double pi_dDeg) {
        return pi_dDeg * (Math.PI/180);
    }

    //endregion
}