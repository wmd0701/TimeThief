package Models;

import Models.*;
import java.io.*;
import play.Logger;
import java.net.URL;
import java.nio.charset.*;
import java.lang.StringBuilder;
import java.net.MalformedURLException;
import javax.net.ssl.HttpsURLConnection;

public class CloudMessage{
    // URL für CloudMessaging
    private static final String ServerURL = "https://fcm.googleapis.com/fcm/send";
    private static final String ServerKey = "AAAAKM_zL9k:APA91bE6Z6QCrxlY0gfNVI2ALOuMJ6OVAYmxHjlSouf7lO8zVkausuMSexcdDiTwB4iGh8t9DgteIz0V3-YezI10d8cBOhWw19B2fWBCUlZS8_JxIdyhuWs3CEQ5Xu4mPEnj8b1WBDSbScsB7GV1nTipXHkQQ6qEGg";

    // Schickt Angriffsnachricht
    // To: Firebase Token des Ziels
    // From: Angreifer (Nickname)
    public void SendAttackMessage(String pi_To, String pi_From){
        String l_JSONData = "{\"Purpose\":\"Attack\",\"Attacker\":\"" + pi_From + "\"}";
        SendMessage(pi_To, l_JSONData, Global.MESSAGEDURATION);
    }

    // Schickt Verteidignachricht
    // To: Firebase Token des Angreifers
    // From: Verteidiger (Nickname)
    public void SendDefendedMessage(String pi_To, String pi_From){
        String l_JSONData = "{\"Purpose\":\"Defended\",\"Defender\":\"" + pi_From + "\"}";
        SendMessage(pi_To, l_JSONData, Global.MESSAGEDURATION);
    }

    // Schickt Freundschaftsanfrage
    // To: Firebase Token des Ziels
    // From: Anfragender Nutzer (Nickname)
    public void SendFriendRequest(String pi_To, String pi_From){
        String l_JSONData = "{\"Purpose\":\"FriendRequest\",\"Requesting\":\"" + pi_From + "\"}";
        // Lange TTL da die Nachricht natürlich nicht sofort ablaufen soll
        SendMessage(pi_To, l_JSONData, 1000000);
    }

    // Sendet eine Nachricht
    // To: Firebase Token des Nutzers
    // Data: Daten als JSON-String
    // TTL: Cachedauer beim Client
    private void SendMessage(String pi_To, String pi_sJSONData, int TTL){
        // Speichert Infos in JSON        
        String toSend = "{" + 
                        "\"to\":\"" + pi_To + "\","+
                        "\"time_to_live\":" + TTL + "," +
                        "\"priority\":\"high\"," +
                        "\"data\":" + pi_sJSONData +
                        "}";
        Logger.info("Message: "+ toSend.replace(pi_To, "(token)"));
        // Try da hier durchaus Fehler auftreten können
        try{
            // Öffne Verbindung
            URL l_ServerURL = new URL(ServerURL);
            HttpsURLConnection l_Con = (HttpsURLConnection) l_ServerURL.openConnection();
            // Soll Daten als POST senden
            l_Con.setDoOutput(true);
            l_Con.setRequestMethod("POST");
            l_Con.setRequestProperty("Authorization", "key="+ServerKey);
            l_Con.setRequestProperty("Content-Type", "application/json");
            // Schreibt in Stream
            OutputStreamWriter l_OutWriter = new OutputStreamWriter(l_Con.getOutputStream());
            l_OutWriter.write(toSend);
            l_OutWriter.close();
            // Und verschickt ihn
            InputStream l_In = l_Con.getInputStream();
            // Gebe Response-Code aus
            Logger.info("Response Code: " + l_Con.getResponseCode());
            // Stringbuilder erstellen
            StringBuilder l_TextBuilder = new StringBuilder();
            Reader reader = new BufferedReader(new InputStreamReader (l_In, Charset.forName(StandardCharsets.UTF_8.name())));
            // String bauen
            int l_cNext = 0;
            while ((l_cNext = reader.read()) != -1) {
                l_TextBuilder.append((char) l_cNext);
            }
            // Ausgeben            
            Logger.info("Delivery: " + (l_TextBuilder.toString().contains("\"success\":1") ? "successful" : "failed"));
        }
        catch(IOException e){
            // IO Fehler: vermutlich von Firebase abgelehnt
            Logger.info("Firebase declined the request");            
        }
        catch(Exception e){
            // Sonstiger Fehler
            Logger.info("Error: " + e.getMessage());
        }
    }

    //------------------------------------------------------------------
    // Singleton
    //------------------------------------------------------------------

    private static CloudMessage instance = null;

    // Get Singleton
    public static CloudMessage getInstance(){
        return instance;
    }

    // Singleton Konstruktor
    public CloudMessage() {
        instance = this;
    }
}