package controllers;

import Models.*;
import play.mvc.*;
import java.time.*;
import java.util.*;
import play.Logger;
import javax.inject.*;
import org.jongo.MongoCollection;
import uk.co.panaxiom.playjongo.*;
import com.fasterxml.jackson.annotation.JsonProperty;

public class HomeController extends Controller {
    
//------------------------------------------------------------------
// Deklarationen
//------------------------------------------------------------------

    @Inject
    // <ID Dieb, <Nickname Opfer, StealingState>>
    private Hashtable<String, Hashtable<String, Global.StealingState>> m_dicIsStealing =
        new Hashtable<String, Hashtable<String, Global.StealingState>>();

    @Inject
    // <Nickname Opfer, <ID Dieb>>
    private Hashtable<String, HashSet<String>> m_dicBeingStolen =
        new Hashtable<String, HashSet<String>>();

    @Inject
    // <ID Nutzer, Zeit des letzten Updates>
    private Hashtable<String, LocalDateTime> m_dicLastSeen =
        new Hashtable<String, LocalDateTime>();

    @Inject
    // <Nutzer die aktuell in einem Timehole sind>
    private HashSet<String> m_lsInTimeHole = new HashSet<String>();

    @Inject
    private UserDatenRepository m_UDR;
    
    @Inject
    private TimeHoleRepository m_TimeHoles;

    @Inject
    private CloudMessage m_CM;

//------------------------------------------------------------------
// Methoden
//------------------------------------------------------------------

    //region Internal

    // Zum "Initialisieren"
    public Result Initiate(){
        m_TimeHoles.Init();
        return ok("Server initialized");
    }

    //endregion

    //region Login/Logout

    public Result Login(String id){
        UserDaten l_UD = m_UDR.getUserByID(id);
        // Falls bereits eingeloggt
        if(m_dicLastSeen.contains(id)){
            // Update einfach nur die Zeit
            UpdateUserTime(l_UD);
        }
        else{
            // Ansonsten speichere Loginzeitpunkt
            m_dicLastSeen.put(id, LocalDateTime.now());
            // Logge bekannte User direkt ein
            if(l_UD != null){ l_UD.login(); }
            // Oder erstelle neuen User
            else {
                l_UD = new UserDaten(id);
                // Speichere in DB
                m_UDR.saveUser(l_UD);
                // Logge den neuen Nutzer ein
                l_UD.login();
            }
            // Info ob neu oder nicht
            Logger.info((l_UD.getNickname().isEmpty() ? "A new user" : l_UD.getNickname()) + " logged in!");
            // Zeit aktualisieren
            UpdateUserTime(l_UD);
        }
        // Übrige Zeit & ob jetzt innerhalb/ausserhalb eines TimeHoles als JSON zurückgeben
        return ok("{" + l_UD.getTimeToLive() + ":" + m_lsInTimeHole.contains(l_UD.getFirebaseID()) + "}");        
    }

    public Result Logout(String id){
        UserDaten l_UD = m_UDR.getUserByID(id);
        // Logout nur erlaubt falls im Zeit-Dictionary
        if(m_dicLastSeen.containsKey(id) && l_UD != null){
            // Nutzer darf sich nur abmelden, wenn er zur Zeit nicht gestohlen ist
            if(!l_UD.getStolen()){
                // Aktualisiere Zeit ein letztes Mal
                UpdateUserTime(l_UD);
                // Entferne User bei Logout aus Dictionary
                m_dicLastSeen.remove(id);
                l_UD.logout();
                Logger.info(l_UD.getNickname() + " logged out");
                return ok(Global.TRUE);
            }
            else{
                Logger.info(l_UD.getNickname() + " fail to log out (being stolen)");
                return ok(Global.FALSE);
            }
        }
        else{
            return ok(Global.FALSE);
        }
    }

    //endregion

    //region Nickname Management

    public Result SetNickname(String id, String nickname){
        UserDaten l_UD = m_UDR.getUserByID(id);
        // Nickname ändern nur erlaubt falls im Zeit-Dictionary
        if(m_dicLastSeen.containsKey(id) && l_UD != null){            
            if(l_UD.setNickname(nickname)){
                Logger.info(l_UD.getNickname() + " (" + id + ") is now called " + nickname);
                return ok(Global.TRUE);                            
            }
            else{
                Logger.info(l_UD.getNickname() + " couldn't set nickname for some reason..");
                return ok(Global.FALSE);
            }
        }
        else {
            return ok(Global.FALSE);
        }
    }

    public Result GetNickname(String id){
        UserDaten l_UD = m_UDR.getUserByID(id);
        // User muss existieren
        if(l_UD != null){
            // Gebe Nickname zurück
            return ok(l_UD.getNickname());
        }
        else {
            // Kein User also ist Rückgabe ein leerer String
            return ok("");
        }
    }

    //endregion

    //region Friend Management

    public Result AddFriend(String id, String nickname){
        UserDaten l_UD1 = m_UDR.getUserByID(id);
        UserDaten l_UD2 = m_UDR.getUserByNickname(nickname);
        // Freund hinzufügen nur erlaubt falls im Zeit-Dictionary
        if(m_dicLastSeen.containsKey(id) && l_UD1 != null && l_UD2 != null){              
            // Doppelte Anfrage nicht erlaubt!
            if(!l_UD1.getRequestedFriends().contains(nickname) && !l_UD1.getFriends().contains(nickname)){
                // Verschicke Anfrage an User
                m_CM.SendFriendRequest(l_UD2.getFirebaseToken(), l_UD1.getNickname());
                // Speichere Anfrage
                l_UD1.requestFriend(nickname);
                Logger.info(l_UD1.getNickname() + " requested " + nickname + " as a friend");
                return ok(Global.TRUE);
            }
            else{                    
                Logger.info(l_UD1.getNickname() + " can't add " + nickname + " as a friend again");
                return ok(Global.FALSE);
            }            
        }
        else{
            return ok(Global.FALSE);
        }
    }

    public Result AcceptFriend(String id, String nickname){
        UserDaten l_UD1 = m_UDR.getUserByID(id);
        UserDaten l_UD2 = m_UDR.getUserByNickname(nickname);
        // Freund hinzufügen nur erlaubt falls im Zeit-Dictionary
        if(m_dicLastSeen.containsKey(id) && l_UD1 != null && l_UD2 != null){
            // Falls eine der Anfragen an diesen User gestellt wurde
            if(l_UD2.getRequestedFriends().contains(l_UD1.getNickname())){
                // Auf beiden Seiten hinzufügen
                l_UD1.addFriend(nickname);
                l_UD2.addFriend(l_UD1.getNickname());
                Logger.info(l_UD1.getNickname() + " accepted " + nickname + " as a friend");
                return ok(Global.TRUE);
            }
            else{
                Logger.info(l_UD1.getNickname() + " can't accept " + nickname + " as a friend");
                return ok(Global.TRUE);
            }
        }
        else{
            return ok(Global.FALSE);
        }
    }

    public Result RemoveFriend(String id, String nickname){
        UserDaten l_UD1 = m_UDR.getUserByID(id);
        UserDaten l_UD2 = m_UDR.getUserByNickname(nickname);
        // Freund entfernen nur erlaubt falls im Zeit-Dictionary
        if(m_dicLastSeen.containsKey(id) && l_UD1 != null && l_UD2 != null){            
            // Entferne auf beiden Seiten
            l_UD1.removeFriend(nickname);
            l_UD2.removeFriend(l_UD1.getNickname());
            Logger.info(l_UD1.getNickname() + " removed " + nickname + " as a friend");
            return ok(Global.TRUE);
        }
        else{
            return ok(Global.FALSE);
        }
    }

    //endregion

    //region Time Manipulation

    public Result ShareTime(String id, String nickname, String amount){
        int l_iAmount = Integer.parseInt(amount);
        UserDaten l_UD1 = m_UDR.getUserByID(id);
        UserDaten l_UD2 = m_UDR.getUserByNickname(nickname);
        // Zeit teilen nur erlaubt falls im Zeit-Dictionary
        if(m_dicLastSeen.containsKey(id)){
            // Es muss genug Zeit übrig sein und beide User müssen existieren            
            if(l_UD1 != null && l_UD2 != null && l_UD1.getTimeToLive() >= l_iAmount){                
                // Falls befreundet und keine Wiederbelebung
                if(l_UD1.getFriends().contains(l_UD2.getNickname()) && l_UD2.getTimeToLive() > 0){
                    // Teile Zeit
                    l_UD1.setTimeToLive(l_UD1.getTimeToLive() - l_iAmount);
                    l_UD2.setTimeToLive(l_UD2.getTimeToLive() + l_iAmount);
                    Logger.info(l_UD1.getNickname() + " shared " + l_iAmount + "s with friend " + nickname);
                    return ok(Global.TRUE);
                }
                // Falls befreundet und Wiederbelebung, dann überprüfe ob im Radius
                else if(l_UD1.getFriends().contains(l_UD2.getNickname()) && l_UD2.getTimeToLive() == 0 &&
                        Global.getDistanceBetween(l_UD1, l_UD2) <= Global.SHARERADIUS){                
                    // Belebe wieder
                    l_UD1.setTimeToLive(l_UD1.getTimeToLive() - l_iAmount);
                    l_UD2.setTimeToLive(l_UD2.getTimeToLive() + l_iAmount);
                    Logger.info(l_UD1.getNickname() + " revived " + nickname + " with " + l_iAmount + "s");
                    return ok(Global.TRUE);
                }
                else{
                    Logger.info(l_UD1.getNickname() + " sharing time failed (requirements not met)");
                    return ok(Global.FALSE);
                }
            }
            else{
                Logger.info(l_UD1.getNickname() + " sharing time failed (user null or amount too big)");
                return ok(Global.FALSE);
            }
        }
        else{
            return ok(Global.FALSE);
        }
    }
    
    public Result BeginSteal(String id, String nickname){
        UserDaten l_UD1 = m_UDR.getUserByID(id);
        UserDaten l_UD2 = m_UDR.getUserByNickname(nickname);
        // Nur erlaubt falls beide aktiv
        if(m_dicLastSeen.containsKey(id) && l_UD1 != null && l_UD2 != null && l_UD2.getActive()){
            // Ziel muss in Reichweite sein
            if(Global.getDistanceBetween(l_UD1, l_UD2) <= Global.STEALRADIUS){
                // Beide müssen am Leben sein
                if(l_UD1.getTimeToLive() > 0 && l_UD2.getTimeToLive() > 0){                
                    // Speichere bestohlenen User
                    if(m_dicBeingStolen.containsKey(nickname))
                        m_dicBeingStolen.get(nickname).add(id);
                    else {
                        m_dicBeingStolen.put(nickname, new HashSet<String>());
                        m_dicBeingStolen.get(nickname).add(id);
                    }
                    // Vom User wird jetzt gestohlen
                    l_UD2.setStolen(true);
                    // Gebe diesem Bescheid
                    m_CM.SendAttackMessage(l_UD2.getFirebaseToken(), l_UD1.getNickname());
                    // Speichere neuen Stealingstate
                    if(m_dicIsStealing.containsKey(id)){
                        // Man darf von jedem User nur einmal gleichzeitig stehlen
                        if(!m_dicIsStealing.get(id).containsKey(nickname)){
                            m_dicIsStealing.get(id).put(nickname, new Global.StealingState());
                        }
                        else{
                            Logger.info(l_UD1.getNickname() + " couldn't steal from " + nickname + " (already stealing)");
                            return ok(Global.FALSE);
                        }
                    }
                    else{
                        // Erstelle neue table
                        m_dicIsStealing.put(id, new Hashtable<String, Global.StealingState>());
                        // Man darf von jedem User nur einmal gleichzeitig stehlen
                        if(!m_dicIsStealing.get(id).containsKey(nickname)){
                            m_dicIsStealing.get(id).put(nickname, new Global.StealingState());

                        }
                        else{
                            Logger.info(l_UD1.getNickname() + " couldn't steal from " + nickname + " (already stealing)");
                            return ok(Global.FALSE);
                        }
                    }
                    // Stehlen erfolgreich begonnen
                    Logger.info(l_UD1.getNickname() + " started stealing from " + nickname);
                    return ok(Global.TRUE);
                }
                else{
                    // Spieler tot
                    Logger.info(l_UD1.getNickname() + " couldn't start stealing from " + nickname + " (player dead)");
                    return ok(Global.FALSE);
                }                
            }
            else{
                // Nicht in Reichweite
                Logger.info(l_UD1.getNickname() + " couldn't start stealing from " + nickname + " (not in range)");
                return ok(Global.FALSE);
            }
        }
        else{
            // Beginnen nicht erfolgreich
            Logger.info(id + " couldn't start stealing from " + nickname + " (other)");
            return ok(Global.FALSE);
        }
    }

    public Result EndSteal(String id, String nickname, String defended){
        // User 1: Angreifer / User 2: Ziel
        UserDaten l_UD1 = m_UDR.getUserByID(id);
        UserDaten l_UD2 = m_UDR.getUserByNickname(nickname);
        boolean l_fDefended = Boolean.parseBoolean(defended);
        // Nur erlaubt falls aktiv
        if(m_dicLastSeen.containsKey(id) && l_UD1 != null && l_UD2 != null){ 
            // User muss im Dictionary sein
            if(m_dicIsStealing.containsKey(id)){
                // User muss vom Ziel aktuell stehlen
                if(m_dicIsStealing.get(id).containsKey(nickname)){
                    // Aktualisiere für User von dem gestohlen wird
                    m_dicBeingStolen.get(nickname).remove(id);
                    // Falls danach keiner mehr stielt entferne
                    if(m_dicBeingStolen.get(nickname).size() == 0)
                        m_dicBeingStolen.remove(nickname);                    
                    // Gestohlene Zeit bestimmen
                    int l_iStolen = m_dicIsStealing.get(id).get(nickname).getStolenTime();
                    // Den Parteien die korrekte Zeit gutschreiben / abziehen
                    l_UD1.setTimeToLive(l_UD1.getTimeToLive() + (l_fDefended ? -l_iStolen : l_iStolen));
                    l_UD2.setTimeToLive(l_UD2.getTimeToLive() + (l_fDefended ? l_iStolen : -l_iStolen));                    
                    // Status des Bestohlenen anpassen
                    l_UD2.setStolen(m_dicBeingStolen.containsKey(nickname));                    
                    // Den Bestohlenen aus dem Dictionary des Stehlenden entfernen
                    m_dicIsStealing.get(id).remove(nickname);
                    // Den Stehlenden aus dem Dictionary entfernen, wenn er von niemanden mehr stiehlt
                    if(m_dicIsStealing.get(id).size() == 0)
                        m_dicIsStealing.remove(id);
                    // Stehlen erfolgreich
                    Logger.info(l_UD1.getNickname() + (l_fDefended ? " lost " : " stole ") + l_iStolen + " from " + l_UD2.getNickname());
                    return ok(Global.TRUE);
                }
                else{
                    // Beenden nicht möglich da nicht im Dictionary
                    Logger.info(l_UD1.getNickname() + " couldn't end stealing from " + l_UD2.getNickname() + " (not being stolen)");
                    return ok(Global.FALSE);
                }
            }
            else{
                // Beenden nicht möglich da nicht im Dictionary
                Logger.info(l_UD1.getNickname() + " couldn't end stealing from " + l_UD2.getNickname() + " (not stealing)");
                return ok(Global.FALSE);
            }            
        }
        else{
            // Beenden nicht möglich
            Logger.info(l_UD1.getNickname() + " couldn't end stealing from " + l_UD2.getNickname() + " (other)");
            return ok(Global.FALSE);
        }
    }

    public Result SendDefendWarning(String id, String nickname){
        // User 1: Verteidiger / User 2: Angreifer
        UserDaten l_UD1 = m_UDR.getUserByID(id);
        UserDaten l_UD2 = m_UDR.getUserByNickname(nickname);
        // Nur erlaubt falls aktiv
        if(m_dicLastSeen.containsKey(id) && l_UD1 != null && l_UD2 != null){
            // Angreifer muss im Dictionary sein
            if(m_dicIsStealing.containsKey(l_UD2.getFirebaseID())){
                // Angreifer muss vom Verteidiger aktuell stehlen
                if(m_dicIsStealing.get(l_UD2.getFirebaseID()).containsKey(l_UD1.getNickname())){
                    // Sende Verteidigungsnachricht an den Angreifer
                    m_CM.SendDefendedMessage(l_UD2.getFirebaseToken(), l_UD1.getNickname());
                    Logger.info(l_UD1.getNickname() + " sent defended to " + l_UD2.getNickname());
                    return ok(Global.TRUE);
                }
                else{
                    // Beenden nicht möglich da nicht im Dictionary
                    Logger.info(l_UD1.getNickname() + " couldn't send defended to " + l_UD2.getNickname() + " (not being stolen)");
                    return ok(Global.FALSE);
                }
            }
            else{
                // Beenden nicht möglich da nicht im Dictionary
                Logger.info(l_UD1.getNickname() + " couldn't send defended to " + l_UD2.getNickname() + " (not stealing)");
                return ok(Global.FALSE);
            }            
        }
        else{
            // Beenden nicht möglich
            Logger.info(l_UD1.getNickname() + " couldn't send defended to " + l_UD2.getNickname() + " (other)");
            return ok(Global.FALSE);
        }
    }

    //endregion

    //region Other

    public Result UpdateFirebaseToken(String id, String token){        
        UserDaten l_UD = m_UDR.getUserByID(id);
        // Token-Update ist jederzeit möglich
        if(l_UD != null){
            // Update Token
            l_UD.setFirebaseToken(token);
            return ok(Global.TRUE);
        }
        else{
            return ok(Global.FALSE);
        }
    }

    public Result GetTitle(String id){
        UserDaten l_UD = m_UDR.getUserByID(id);
        // Nur erlaubt wenn aktiv
        if(m_dicLastSeen.containsKey(id) && l_UD != null){
            // Gebe Titel zurück je nach dem wie lange der Nutzer überlebt hat
            if(l_UD.getSurvived() >= 1000 && l_UD.getSurvived() < 2000){
                return ok("\"Average Joe\"");
            } 
            else if(l_UD.getSurvived() >= 2000 && l_UD.getSurvived() < 4000){
                return ok("\"2 Fast 4 U\"");
            }
            else if(l_UD.getSurvived() >= 4000 && l_UD.getSurvived() < 10000){            
                return ok("\"Neo From The Matrix\"");
            }
            else if(l_UD.getSurvived() >= 10000){                
                return ok("\"Older Than The Universe\"");
            }
            else{
                return ok("\"Molasses In Winter\"");
            }
        }
        else{
            return ok("Invalid");
        }
    }

    public Result GetRanking(String id){
        UserDaten l_UD = m_UDR.getUserByID(id);        
        TreeMap<Long, String> ranking = new TreeMap<Long, String>();
        // Nur erlaubt wenn aktiv
        if(m_dicLastSeen.containsKey(id) && l_UD != null){ 
            // Hole alle User als Array
            for (UserDaten user : m_UDR.getAllUsers()){
                ranking.put(user.getSurvived(), user.getNickname());                
            }
        }
        // Hole ersten Eintrag
        String result = "[";
        Map.Entry<Long, String> curr = ranking.pollLastEntry();
        // Polle solange bis Ende erreicht, füge zum String hinzu
        while(curr != null){
            result += ",{" + curr.getValue() + ":" + curr.getKey() + "}";
            curr = ranking.pollLastEntry();
        }
        // Entferne erstes Komma und füge abschließende Klammer hinzu
        result = result.replaceFirst(",","") + "]";        
        // Rückgabe als JSON String
        return ok(result);
    }

    public Result GetFriends(String id){
        UserDaten l_UD = m_UDR.getUserByID(id);
        // Erstelle Dictionary mit Nickname/TTL
        HashSet<String> result = new HashSet<String>();
        // Nur erlaubt wenn aktiv
        if(m_dicLastSeen.containsKey(id) && l_UD != null){ 
            // Gehe durch die Freunde
            for(String nickname : l_UD.getFriends()){
                UserDaten friend = m_UDR.getUserByNickname(nickname);
                // Falls Freund existiert
                if(friend != null){
                    // Füge hinzu
                    result.add(friend.getNickname());
                }
            }
        
        }
        // Rückgabe als JSON String
        return ok(Global.CollectionToJSON(result));
    }

    public Result GetActiveOfFriend(String id, String nickname){
        UserDaten l_UD1 = m_UDR.getUserByID(id);
        UserDaten l_UD2 = m_UDR.getUserByNickname(nickname);
        // User muss aktiv sein und beide müssen existieren
        if(m_dicLastSeen.containsKey(id) && l_UD1 != null && l_UD2 != null){
            // Gebe zurück ob Nutzer online falls befreundet
            if(l_UD1.getFriends().contains(l_UD2.getNickname())){
                return ok(l_UD2.getActive() ? Global.TRUE : Global.FALSE);
            }
            else{
                return ok(Global.FALSE);
            }
        }
        else{
            return ok(Global.FALSE);
        }
    }

    //endregion

    //region Updating

    public Result GetActiveUsers(String id, String radius){
        int l_iRadius = Integer.parseInt(radius);
        UserDaten l_UD = m_UDR.getUserByID(id);
        // Erstelle neues Dictionary mit Nickname/Location
        Hashtable<String, Global.Location> ret = new Hashtable<String, Global.Location>();
        // Nur erlaubt wenn aktiv
        if(m_dicLastSeen.containsKey(id) && l_UD != null){ 
            // Speichere alle User
            HashSet<UserDaten> allUsers = m_UDR.getAllUsers();
            // Loope sie
            for(UserDaten currUser : allUsers){
                // Falls User aktiv und nicht der aufrufende User
                if(currUser.getActive() && !currUser.getFirebaseID().equals(l_UD.getFirebaseID())){
                    // Falls in der Nähe (im Radius)
                    if(Global.getDistanceBetween(l_UD, currUser) <= l_iRadius){
                        // Speichere im Dictionary
                        ret.put(currUser.getNickname(), currUser.getLocation());
                    }
                }
            }
        }
        // Rückgabe als JSON String
        return ok(Global.TableToJSON(ret));
    }

    public Result GetTimeHoles(String id, String radius){
        int l_iRadius = Integer.parseInt(radius);
        UserDaten l_UD = m_UDR.getUserByID(id);
        HashSet<Global.Location> result = new HashSet<Global.Location>();
        // Nur erlaubt wenn aktiv
        if(m_dicLastSeen.containsKey(id) && l_UD != null){
            // Speichere alle TimeHoles
            HashSet<Global.Location> all = m_TimeHoles.getTimeHoles();
            // Loope sie
            for(Global.Location l : all){
                // Falls TimeHole im Radius
                if(Global.getDistanceBetween(l_UD, l) <= l_iRadius){
                    // Speichere im Dictionary
                    result.add(l);
                }
            }
        }
        // Rückgabe als JSON String
        return ok(Global.CollectionToJSON(result));
    }

    public Result GetTimeSurvived(String id){
        UserDaten l_UD = m_UDR.getUserByID(id);
        // Nur erlaubt falls aktiv
        if(m_dicLastSeen.containsKey(id) && l_UD != null){
            // Zeit aktualisieren
            UpdateUserTime(l_UD);
            // Zeit zurückgeben
            return ok("" + l_UD.getSurvived());        
        }
        else{
            return ok("-1");
        }
    }

    public Result Update(String id, String longitude, String latitude){
        double l_dLongitude = Double.parseDouble(longitude);
        double l_dLatitude  = Double.parseDouble(latitude);
        UserDaten l_UD = m_UDR.getUserByID(id);
        // Update nur erlaubt falls im Zeit-Dictionary
        if(m_dicLastSeen.containsKey(id) && l_UD != null){            
            // Position aktualisieren
            l_UD.updateLocation(l_dLongitude, l_dLatitude);
            // Zeit aktualisieren
            UpdateUserTime(l_UD);
            // Bestehlen aktualisieren
            UpdateUserStealing(l_UD);
            // Übrige Zeit & ob jetzt innerhalb/ausserhalb eines TimeHoles als JSON zurückgeben
            return ok("{" + l_UD.getTimeToLive() + ":" + m_lsInTimeHole.contains(l_UD.getFirebaseID()) + "}");
        }
        else{
            // User nicht aktiv
            return ok("{-1:false}");
        }
    }

    //endregion

    //region Utilitly

    // Aktualisiert übrige Zeit eines Users
    private void UpdateUserTime(UserDaten pi_UD){
        // Der User muss eingeloggt sein!
        if(m_dicLastSeen.containsKey(pi_UD.getFirebaseID()) && pi_UD.getActive()){            
            // TTL Update (Zeitdifferenz * Faktor wenn Nutzer in Timehole)
            pi_UD.setTimeToLive(pi_UD.getTimeToLive() +
                (long) (Duration.between(m_dicLastSeen.get(pi_UD.getFirebaseID()), 
                                        LocalDateTime.now()).getSeconds() * 
                        (UserInTimehole(pi_UD) ? Global.CHARGEFACTOR : -1)));
            // Überlebte Zeit aktualisieren (Nur tatsächlich gespielte Zeit!)
            pi_UD.setSurvived(pi_UD.getSurvived() + 
                Duration.between(m_dicLastSeen.get(pi_UD.getFirebaseID()), 
                                LocalDateTime.now()).getSeconds());
            // Letzte Zeit aktualisieren
            m_dicLastSeen.replace(pi_UD.getFirebaseID(), LocalDateTime.now());
        }
        else{
            Logger.info(pi_UD.getNickname() + " wasn't in time dictionary or active!");
        }
    }

    // Beendet stehlen automatisch falls nicht mehr in Reichweite
    private void UpdateUserStealing(UserDaten pi_UD){
        // Falls User aktuell stiehlt
        if(m_dicIsStealing.containsKey(pi_UD.getFirebaseID())){
            // Für alle Opfer
            for(String sVictim : m_dicIsStealing.get(pi_UD.getFirebaseID()).keySet()){
                UserDaten l_UD = m_UDR.getUserByNickname(sVictim);
                // Opfer muss existieren
                if(l_UD != null){
                    // Falls nicht mehr in Reichweite
                    if(Global.getDistanceBetween(pi_UD, l_UD) > Global.STEALRADIUS){
                        // Beende stehlen
                        EndSteal(pi_UD.getFirebaseID(), sVictim, "false");
                        Logger.info(pi_UD.getNickname() + " was stopped from stealing from " + sVictim);
                    }
                }
                else{
                    Logger.info(pi_UD.getNickname() + " couldn't check updated distance!");
                }
            }
        }
    }

    // Bestimmt ob User in beliebigem Timehole ist
    private boolean UserInTimehole(UserDaten pi_UD){
        // Loope alle Timeholes
        for(Global.Location hole : m_TimeHoles.getTimeHoles()){
            // Falls im Radius eines Timeholes            
            if(Global.getDistanceBetween(pi_UD, hole) <= Global.CHARGERADIUS){
                // Falls schon länger im Timehole
                if(m_lsInTimeHole.contains(pi_UD.getFirebaseID())){
                    // Dann in Timehole
                    return true;
                }
                // Ansonsten jetzt im Timehole
                else{
                    // Füge in Liste ein
                    m_lsInTimeHole.add(pi_UD.getFirebaseID());
                    // Aufladen erst beim zweiten Mal
                    return false;
                }
            }
        }
        // Keines in Reichweite -> return war User davor in Timehole
        return m_lsInTimeHole.remove(pi_UD.getFirebaseID());
    }

    //endregion
}