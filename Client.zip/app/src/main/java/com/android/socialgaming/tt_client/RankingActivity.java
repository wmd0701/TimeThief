package com.android.socialgaming.tt_client;

import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.TextView;

import com.android.socialgaming.tt_client.util.httpGetter;
import com.google.android.gms.common.data.TextFilterable;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

public class RankingActivity extends AppCompatActivity {

    private TextView RankingText;
    private httpGetter getter;
    private String result = "";
    private String PlayerID = "";
    private String[] RankingList;
    private List<TextView> TimeSurvivedViews = new ArrayList<TextView>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ranking);
        PlayerID = MenuActivity.getPlayerID();
        RankingText = (TextView) findViewById(R.id.text_ranking);
        updateRankingList();
        reworkArray();
        upDateRankingText();

    }


    private void reworkArray() {
        String[] list = {"-", "-", "-"};
        if (RankingList == null)
            RankingList = list;
        else if (RankingList.length < 3) {
            for (int i = 0; i < RankingList.length; i++)
                list[i] = RankingList[i];
            RankingList = list;
        }


    }

    private void upDateRankingText() {
        RankingText.setText("");


        for (int i = 0; i < RankingList.length; i++)
            RankingText.append(RankingList[i] + "\n");

    }

    private void updateRankingList() {
        getter = new httpGetter();
        getter.execute("GetRanking", PlayerID);

        try {
            result = getter.get();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }

        RankingList = GetList(result);

        changeText();
    }

    //converts the output of the server method into an array with all the users organized
    private String[] GetList(String buffer) {
        List<Integer> KommaPos = new ArrayList<Integer>();
        int begin = 1;
        int last = buffer.length() - 1;
        int j = 0;
        for (int i = 0; i < buffer.length(); i++) {
            if (buffer.charAt(i) == ',')
                KommaPos.add(i);
        }


        String[] listofCouple = new String[KommaPos.size() + 1];

        //0 friend
        if (buffer.charAt(0) == '[' && buffer.charAt(1) == ']')
            return null;

        //1 friend
        if (KommaPos.size() == 0) {
            listofCouple[0] = buffer.substring(begin, last);
            return listofCouple;
        }

        while (j <= KommaPos.size()) {
            listofCouple[j] = buffer.substring(begin, KommaPos.get(j));
            begin = KommaPos.get(j) + 1;
            j++;
            if (j >= KommaPos.size()) {
                listofCouple[KommaPos.size()] = buffer.substring(begin, result.length() - 1);
                break;
            }
        }

        return listofCouple;
    }

    private void addTimeSurvived() {
        TimeSurvivedViews.clear();

        for (int i = 0; i < RankingList.length; i++) {
            getter = new httpGetter();
            TimeSurvivedViews.add(new TextView(this));
            getter.execute("GetTimeSurvived", PlayerID);
            try {
                TimeSurvivedViews.get(i).setText(TimeFormat(getter.get()));
            } catch (InterruptedException e) {
                e.printStackTrace();
            } catch (ExecutionException e) {
                e.printStackTrace();
            }
        }
    }


    private String TimeFormat(String s) {

        int time = Integer.parseInt(s);
        int hours = (int) (time / 3600);
        int minutes = (int) ((time % 3600) / 60);
        int seconds = (int) ((time % 3600) % 60);

        String timeLeft = String.format("%02d:%02d:%02d", hours, minutes, seconds);
        return timeLeft;
    }


    private void changeText() {
      for (int i = 0; i < RankingList.length; i++) {
            String modified = RankingList[i].substring(1, RankingList[i].length() - 1);

            for (int j = 0; j < modified.length(); j++) {
                if (modified.charAt(j) == ':') {
                    String time = modified.substring(j + 1, modified.length());
                    modified = modified.substring(0, j) + "  " + time+"TS";

                }

                RankingList[i] = modified;
          }
        }

    }

}
