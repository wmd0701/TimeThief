package com.android.socialgaming.tt_client;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Build;
import android.provider.Settings;
import android.support.annotation.RequiresApi;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.socialgaming.tt_client.util.Service;
import com.android.socialgaming.tt_client.util.httpGetter;
import com.android.socialgaming.tt_client.util.httpPoster;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.GoogleMap.OnMapClickListener;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.Circle;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MapStyleOptions;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;

public class MapsActivity extends AppCompatActivity implements OnMapReadyCallback {

    ArrayList<Marker> timeHolesMarkers ;
    ArrayList<Marker> otherPlayerMarkers ;
    ArrayList<Circle> timeHolesCircleList ;
    String currentPlayerID  ;
    //map
    SupportMapFragment mapFragment ;
    private GoogleMap mMap ;
    //this classes will be controlling the current location
    private LocationListener locationListener ;
    //Marker variables
    private Marker  GarchingTS ;
    private MarkerOptions markerOptions  ;
    private Marker playerMarker ;
    private Circle circle ;
    boolean cond = true ;
    CircleOptions circleOptions ;
    //info window layout
    private ViewGroup infoWindow;
    private Button infoButton;




    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);

        //start the map
        initMap();






        //init LocationListner
        locationListener = new LocationListener() {

            @Override
            public void onLocationChanged(Location location) {
                //current Location
              //  latitude = location.getLatitude();
              //  longitude = location.getLongitude();





                circleOptions = createCircle(Service.latLng,100,Color.TRANSPARENT , true) ;
                circleOptions.strokeColor(Color.RED);

                SetTimeHolesLocations(Service.listTimeHoles);
               SetMarker(circleOptions,Service.latLng.latitude ,Service.latLng.longitude) ;
               SetOtherPlayersMarker(Service.listActiveUsers);



            }

            @Override
            public void onStatusChanged(String s, int i, Bundle bundle) {

            }

            @Override
            public void onProviderEnabled(String s) {

            }

            @Override
            public void onProviderDisabled(String s) {
                //if the GPS is disabled start the setting menu to turn it on
                Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                startActivity(intent);

            }
        };

        // check for location Permission
        checkForPermission();

       Service.locationManager.requestLocationUpdates("gps", 15, 2, locationListener);


    }




    //set the Player marker in the map
    private void SetMarker(CircleOptions circleOptions,Double longitude ,double latitude) {
        LatLng latLng = new LatLng(latitude,longitude);
        if (playerMarker == null){
            playerMarker =  mMap.addMarker(new MarkerOptions().position(latLng).snippet(MenuActivity.Nickname).icon(BitmapDescriptorFactory.fromResource( R.mipmap.player )));
            circle = mMap.addCircle(circleOptions);
            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng , 15.00f));
        }
        else {
            playerMarker.setPosition(latLng);
            circle.setCenter(latLng);
        }
    }


    private void SetOtherPlayersMarker(ArrayList<String> buffer){

        if ( buffer == null) {
            return;
        }
        else {
            if ( !otherPlayerMarkers.isEmpty()) {
                for (Marker s : otherPlayerMarkers){
                    Marker marker = s;
                    marker.remove();
                }

            otherPlayerMarkers.clear();



            }
            int j = 1;

            for (int i = 0; i < buffer.size(); i += 3) {

                String latitudeString = buffer.get(j );
                double latitude = Double.parseDouble(latitudeString);

                String longitudeString = buffer.get(j+1);

                double longitude = Double.parseDouble(longitudeString);

                LatLng latLng = new LatLng(latitude , longitude);

                Marker enemyMarker = mMap.addMarker(new MarkerOptions().snippet(buffer.get(i)).position(latLng).icon(BitmapDescriptorFactory.fromResource(R.mipmap.enemy)));

                otherPlayerMarkers.add(enemyMarker);

                j += 3;
            }
        }
    }
    //Set Time Holes locations
    private void SetTimeHolesLocations ( ArrayList<String> buffer){

        if ( buffer == null){
            return ;
        }
                   timeHolesMarkers.clear();
        timeHolesCircleList.clear();
            for (int j = 0; j < buffer.size(); j += 2) {

                String latitudeString = buffer.get(j + 1 );
                double latitude = Double.parseDouble(latitudeString);

                String longitudeString = buffer.get(j );

                double longitude = Double.parseDouble(longitudeString);

                LatLng latLng = new LatLng(longitude, latitude);
                CircleOptions timeHolesCircle = createCircle(latLng , 100 ,Color.TRANSPARENT ,true);
                timeHolesCircle.strokeColor(Color.BLUE) ;
                Circle circle = mMap.addCircle(timeHolesCircle) ;
                Marker timehole = mMap.addMarker(new MarkerOptions().snippet("Time Hole").position(latLng).icon(BitmapDescriptorFactory.fromResource(R.mipmap.watch)));
                timeHolesCircleList.add(circle);
                timeHolesMarkers.add(timehole);


            }


    }



    // Obtain the SupportMapFragment and get notified when the map is ready to be used.
    public void initMap() {
        mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
        otherPlayerMarkers = new ArrayList<Marker>() ;
        timeHolesMarkers = new ArrayList<Marker>() ;
        timeHolesCircleList = new ArrayList<Circle>();

    }

    public CircleOptions createCircle(LatLng currentLatLng , int radius , int color , boolean clickable) {
        CircleOptions circleOptions  = new CircleOptions();
        circleOptions.center(currentLatLng) ;
        circleOptions.fillColor(color) ;
        circleOptions.radius(radius);
        circleOptions.clickable(clickable);
        return circleOptions ;
    }

    public void checkForPermission(){
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION,Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.INTERNET}
                        ,10);
            }
            return;
        }
    }
    private Double CalculateDistance(LatLng point1 , LatLng point2){
        double distance  ;
        double R = 6371000.0;
        double angle1 = Math.toRadians(point1.latitude );
        double angle2  = Math.toRadians(point2.latitude );
        double delta1 = Math.toRadians(point1.latitude - point2.latitude );
        double delta2 = Math.toRadians(point1.longitude - point2.longitude );
        double a =  Math.sin(delta1/2) *Math.sin(delta1/2) + Math.cos(angle1) *Math.cos(angle2) * Math.sin(delta2/2) * Math.sin(delta2/2);
        double c = 2*Math.atan2(Math.sqrt(a),Math.sqrt(1-a)) ;
         distance = R*c ;


        return distance ;
    }



    private ArrayList<String> GetTimeHolesList(String line)    {
        int commaNbr = 0 ;
        int dpp = 0;
        ArrayList<String> list = new ArrayList<String>();
if ( line.equals("[]")) {
    return null ;
}
else {
    for (int i = 0; i < line.length(); i++) {
        char itr = line.charAt(i);
        if (itr == ',') {
            commaNbr++;

        } else if (itr == ':') {
            dpp++;
        }
    }

    int commaPos[] = new int[commaNbr];
    int doublePointsPos[] = new int[dpp];
    int j = 0;
    int z = 0;
    for (int i = 0; i < line.length(); i++) {
        char itr = line.charAt(i);
        if (itr == ',') {
            commaPos[j] = i;
            j++;

        } else if (itr == ':') {
            doublePointsPos[z] = i;
            z++;
        }
    }

    int k = 0;

    for (int i = 0; i < dpp - 1; i++) {

        String sub = line.substring(doublePointsPos[i] + 1, commaPos[k]);
        list.add(sub);
        i++;
        if (k < commaNbr - 1) {
            k++;
            sub = line.substring(doublePointsPos[i] + 1, commaPos[k] - 1);
            list.add(sub);
            k++;
        }
    }

    String sub = line.substring(doublePointsPos[dpp - 1] + 1, line.length() - 2);
    list.add(sub);
    return list;
}
    }


    // get the information from the JsonObject
    private ArrayList<String> GetList(String line){
          if ( line.equals("{}")){
            return null ;
        }
        else {
            int commaNbr = 0;
            int dpp = 0;
            ArrayList<String> list = new ArrayList<String>();

            for (int i = 0; i < line.length(); i++) {
                char itr = line.charAt(i);
                if (itr == ',') {
                    commaNbr++;

                } else if (itr == ':') {
                    dpp++;
                }
            }


            int commaPos[] = new int[commaNbr];
            int doublePointsPos[] = new int[dpp];
            int j = 0;
            int z = 0;
            for (int i = 0; i < line.length(); i++) {
                char itr = line.charAt(i);
                if (itr == ',') {
                    commaPos[j] = i;
                    j++;

                } else if (itr == ':') {
                    doublePointsPos[z] = i + 1;
                    z++;
                }
            }


            String sub = line.substring(1, doublePointsPos[0] - 1);
            list.add(sub);


            int k = 0;
            for (int i = 1; i < dpp - 2; i += 3) {
                String sub1 = line.substring(doublePointsPos[i], commaPos[k]);
                String sub2 = line.substring(doublePointsPos[i + 1], commaPos[k + 1] - 1);
                String sub3 = line.substring(commaPos[k + 1] + 1, doublePointsPos[i + 2] - 1);
                k += 2;
                list.add(sub1);
                list.add(sub2);
                list.add(sub3);

            }

            sub = line.substring(doublePointsPos[doublePointsPos.length - 2], commaPos[commaPos.length - 1]);
            list.add(sub);
            sub = line.substring(doublePointsPos[doublePointsPos.length - 1], line.length() - 2);
            list.add(sub);


            return list;
        }
    }


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;




        mMap.setMapStyle( MapStyleOptions.loadRawResourceStyle(this, R.raw.style_json));


        currentPlayerID = MenuActivity.getPlayerID(); ;

        if (mMap != null){


            googleMap.setInfoWindowAdapter(new GoogleMap.InfoWindowAdapter() {

                @Override
                public View getInfoWindow(Marker marker) {
                    return null;
                }
                @Override
                public View getInfoContents(Marker marker) {

                        View infoWindow = getLayoutInflater().inflate(R.layout.info_window, null);
                        TextView playerName = (TextView) infoWindow.findViewById(R.id.text_playerName);
                        TextView text_distance = (TextView) infoWindow.findViewById(R.id.text_distance);
                        float[] distance = new float[1];
                        LatLng ll = marker.getPosition();
                        LatLng playerLL = playerMarker.getPosition();
                      //  double distance = CalculateDistance(ll , playerLL);
                        Location.distanceBetween(ll.latitude, ll.longitude, playerLL.latitude, playerLL.longitude, distance);
                        String num = String.format("%.2f" , distance[0]/1000) ;
                        text_distance.setText("Distance :" + num + "Km");
                        playerName.setText(marker.getSnippet());
                        //ImageView image = (ImageView)infoWindow.findViewById((R.id.player_image));
                        return infoWindow;





                }
            });
        }

        mMap.setOnInfoWindowClickListener(new GoogleMap.OnInfoWindowClickListener() {
            @Override
            public void onInfoWindowClick(Marker marker) {
                float[] distance = new float[1];
                LatLng ll = marker.getPosition();
                LatLng playerLL = playerMarker.getPosition();
                Location.distanceBetween(ll.latitude, ll.longitude, playerLL.latitude, playerLL.longitude, distance);
                if (!marker.getSnippet().equals(playerMarker.getSnippet()) && (distance[0]/1000) <= 1.0  && !marker.getSnippet().equals("Time Hole")) {
                    Intent intent = new Intent(getApplicationContext(), actionMenu.class);
                    intent.putExtra("nickname", marker.getSnippet());
                    startActivity(intent);
                }
                else {
                    return ;
                }
            }
        });

        //if a marker is being cicked by the player
        mMap.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener() {
            @Override
            public boolean onMarkerClick(Marker marker) {
                return false;
            }
        });

        mMap.setOnCircleClickListener(new GoogleMap.OnCircleClickListener() {
            @Override
            public void onCircleClick(Circle clickedCircle) {


            }
        });

        mMap.setOnMapClickListener(new OnMapClickListener() {



            @Override
            public void onMapClick(LatLng circleLatLng ) {

            }

        });



    }
}

