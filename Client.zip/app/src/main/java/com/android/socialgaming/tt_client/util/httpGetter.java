package com.android.socialgaming.tt_client.util;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.Toast;

import com.android.socialgaming.tt_client.MapsActivity;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Map;

public class httpGetter extends AsyncTask <String,String,String> {

   private String standardURL = "http://79.133.48.208:9000" ;
   private String serverURL ;
   private String httpGetResult ;

   public httpGetter(String URL) {
       this.serverURL =URL;
   }
    public httpGetter() {
        this.serverURL = standardURL;
    }
    @Override
    protected String doInBackground(String... strings) {
        BufferedReader inBuffer = null ;
        String url = this.serverURL;
        String result ="fail";
        for(String parameter:strings){
            url = url+"/"+parameter ;
        }
        try{
            URL getter = new URL(url);
            HttpURLConnection connection = (HttpURLConnection) getter.openConnection();
            connection.setRequestMethod("GET");
            connection.connect();
           BufferedReader bf = new BufferedReader((new InputStreamReader(connection.getInputStream())));
            result = bf.readLine();
            httpGetResult = bf.readLine();
       //    System.out.println(result);



          // result = convertInputStreamToString(getter.openConnection().getInputStream());

           //result = connection.getResponseMessage();


        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (inBuffer != null){
                try {
                    inBuffer.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return result;
    }


    private String convertInputStreamToString(InputStream inputStream) throws IOException {
       BufferedReader bufferedReader = new BufferedReader((new InputStreamReader(inputStream)));
       String line = "";
       String result = "";
       while((line = bufferedReader.readLine())!= null){
           result += line ;
       }
       inputStream.close();
       return result;
    }
@Override
    protected  void onPostExecute(String result){
       httpGetResult = result ;
    }
    public String getResult(){
       return httpGetResult ;
    }
}
