package com.android.socialgaming.tt_client;

import android.support.v4.content.LocalBroadcastManager;
import android.util.Log;

import android.content.Intent;

import android.widget.Toast;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

public class FirebaseListener extends FirebaseMessagingService {

    public static String target;

    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        if(remoteMessage.getData().size() > 0){
            Log.d("INFORMATION","BEEING CALLED THOUGH!");
            String purpose = remoteMessage.getData().get("Purpose");
            if(purpose == null)
                return;
            switch(purpose){
                case "":
                    break;
                case "FriendRequest":
                    target = remoteMessage.getData().get("Requesting");
                    Intent dialogIntent = new Intent(this, RequestActivity.class);
                    dialogIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(dialogIntent);
                    break;
                case "Attack":
                    Log.d("INFORMATION","BEEING attacked!");
                    target = remoteMessage.getData().get("Attacker");
                    Intent dialogIntents = new Intent(this, DefendActivity.class);
                    dialogIntents.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(dialogIntents);
                    break;
                case "Defended":
                    Log.d("INFORMATION", "BEEING defended!");
                    target = remoteMessage.getData().get("Defender");
                    Intent intent = new Intent("FCM_Message");
                    LocalBroadcastManager localBroadcastManager = LocalBroadcastManager.getInstance(this);
                    localBroadcastManager.sendBroadcast(intent);
            }
        }
    }

}
