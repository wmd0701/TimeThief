package com.android.socialgaming.tt_client;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.socialgaming.tt_client.util.httpGetter;

import java.util.concurrent.ExecutionException;

public class ShareActivity extends AppCompatActivity implements View.OnClickListener{

    private Button End;
    private Button Confirm;
    private TextView SharedTime;
    private String SharedAmount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_share);
        End = findViewById(R.id.endSharing);
        End.setOnClickListener(this);
        Confirm = findViewById(R.id.ShareConfirm);
        Confirm.setOnClickListener(this);
        SharedTime = findViewById(R.id.SharedTime);
    }

    @Override
    public void onClick(View v) {
        if(v == End){
            finish();
            startActivity(new Intent(this, MenuActivity.class));
        }
        if(v == Confirm){
            SharedAmount = ""+SharedTime.getText();
            try {
                int x = Integer.parseInt(SharedAmount);
            } catch (NumberFormatException e) {
                Toast.makeText(this,"Invalid amount of Time!", Toast.LENGTH_LONG).show();
                return;
            }
            String result = "true";
            httpGetter getter = new httpGetter();
            getter.execute("ShareTime", MenuActivity.getPlayerID(), getIntent().getStringExtra("target"), SharedAmount);

            try {
                result = getter.get();
            } catch (InterruptedException e) {
                e.printStackTrace();
            } catch (ExecutionException e) {
                e.printStackTrace();
            }
            if(result.equals("false")){
                Toast.makeText(this,"That is more time than you have!", Toast.LENGTH_LONG).show();
            }

            Toast.makeText(this,"Succesfully Shared!", Toast.LENGTH_LONG).show();
            finish();
            startActivity(new Intent(this, MenuActivity.class));
        }
    }


}
