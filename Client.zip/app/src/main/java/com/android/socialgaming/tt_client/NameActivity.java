package com.android.socialgaming.tt_client;

import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.socialgaming.tt_client.util.Service;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.android.socialgaming.tt_client.util.httpGetter;
import com.android.socialgaming.tt_client.util.httpPoster;

import java.util.concurrent.ExecutionException;

public class NameActivity extends AppCompatActivity implements View.OnClickListener{
    private httpGetter getter;
    private FirebaseAuth firebaseAuth;
    private String ID;
    private EditText nameView;
    private Button ok;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_name);
        nameView = (EditText) findViewById(R.id.newname);
        ok = (Button) findViewById(R.id.confirm);
        ok.setOnClickListener(this);
        firebaseAuth = FirebaseAuth.getInstance();
        if(firebaseAuth.getCurrentUser() == null){
            finish();
            startActivity(new Intent(this, LoginActivity.class));
        }
        FirebaseUser user = firebaseAuth.getCurrentUser();
        ID = user.getUid();
        AlertDialog.Builder mBuilder = new AlertDialog.Builder(NameActivity.this);
        View mView = getLayoutInflater().inflate(R.layout.tutorial_dialog, null);
        mBuilder.setView(mView);
        AlertDialog tut = mBuilder.create();
        tut.show();
    }


    @Override
    public void onClick(View v) {
        if(v == ok){
            String nickname = nameView.getText().toString().trim();
            if(TextUtils.isEmpty(nickname)){
                Toast.makeText(this,"Please enter a nickname",Toast.LENGTH_SHORT).show();
                return;
            }else{
                String nottaken = "true";
                getter = new httpGetter();
                getter.execute("SetNickname", ID, nickname);
                try {
                    nottaken = getter.get();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                } catch (ExecutionException e) {
                    e.printStackTrace();
                }
                if(nottaken.equals("false")){
                    Toast.makeText(this, "Nickname already taken", Toast.LENGTH_LONG).show();
                    return;
                }
                finish();
                startActivity(new Intent(this,MenuActivity.class));
            }
        }
    }
}
