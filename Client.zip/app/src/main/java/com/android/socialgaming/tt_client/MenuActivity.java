package com.android.socialgaming.tt_client;


import com.android.socialgaming.tt_client.util.Service;
import com.android.socialgaming.tt_client.util.httpGetter;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.iid.FirebaseInstanceId;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

public class MenuActivity extends AppCompatActivity {

    private httpGetter getter;
    private static final long START_TIME_IN_MILLS = 14440000; //24 hours countdown
    private static TextView TextViewCountdown;
    private static TextView TextViewDead;
    private static EditText Hr;
    private static EditText Mn;
    private static EditText Sec;
    private EditText Name;
    private ImageView TitleIcon;

    private Button ButtonFriends;
    private Button ButtonRanking;
    private Button ButtonLogout;
    private Button ButtonMap;

    private static CountDownTimer cdt = null;

    public static String Nickname;
    private String Title;
    public static String currentPlayerID = "";
    private static long TimeLeftInMillis = START_TIME_IN_MILLS;
    private static long TimeLeftInSecs = TimeLeftInMillis / 1000;
    FirebaseAuth firebaseAuth;
    private Intent service;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        firebaseAuth = FirebaseAuth.getInstance();
        if (firebaseAuth.getCurrentUser() == null) {
            finish();
            startActivity(new Intent(this, LoginActivity.class));
        }
        FirebaseUser user = firebaseAuth.getCurrentUser();
        currentPlayerID = user.getUid();

        getter = new httpGetter();
        getter.execute("Login", currentPlayerID);

        getter = new httpGetter();
        getter.execute("GetNickname", currentPlayerID);
        try {
            Nickname = getter.get();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }

        if (Nickname == null) {
            finish();
            Intent intent = new Intent(this, NameActivity.class);
            startActivity(intent);
        }else{
            getter = new httpGetter();
            getter.execute("Login", currentPlayerID);
            try {
                TimeLeftInSecs = Integer.parseInt(getTime(getter.get()));
            } catch (InterruptedException e) {
                e.printStackTrace();
            } catch (ExecutionException e) {
                e.printStackTrace();
            }

            startTimer(TimeLeftInSecs,1000);

            String refreshedToken = FirebaseInstanceId.getInstance().getToken();
            Log.d("INFORMATION", "Refreshed token: " + refreshedToken);
            MenuActivity.SendToken(refreshedToken);

            service = new Intent(getApplicationContext(), Service.class);
            this.startService(service);
            getter = new httpGetter();
            getter.execute("GetNickname", currentPlayerID);
            try {
                Nickname = getter.get();
            } catch (InterruptedException e) {
                e.printStackTrace();
            } catch (ExecutionException e) {
                e.printStackTrace();
            }



            getter = new httpGetter();
            getter.execute("GetTitle", currentPlayerID);
            try {
                Title = getter.get();
            } catch (InterruptedException e) {
                e.printStackTrace();
            } catch (ExecutionException e) {
                e.printStackTrace();
            }

            Name = findViewById(R.id.nickname);
            Name.setText(Title + " "+ Nickname);

            TitleIcon = (ImageView) findViewById(R.id.imageView5);
            updateTitleIcon();

            TextViewCountdown = findViewById(R.id.text_view_countdown);
            Hr = findViewById(R.id.editText2);
            Mn = findViewById(R.id.editText5);
            Sec = findViewById(R.id.editText4);
            TextViewDead = findViewById(R.id.text_view_dead);
            ButtonFriends = findViewById(R.id.button_Friends);
            ButtonRanking = findViewById(R.id.button_Ranking);
            ButtonLogout = findViewById(R.id.button_logout);
            ButtonMap = findViewById(R.id.button_MAP);



            ButtonMap.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(!Service.dead) {
                        Intent intent = new Intent(getApplicationContext(), MapsActivity.class);
                        startActivity(intent);
                    }
                }
            });
            ButtonFriends.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(getApplicationContext(), FriendsActivity.class);
                    startActivity(intent);
                }
            });

            ButtonRanking.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(getApplicationContext(), RankingActivity.class);
                    startActivity(intent);
                }
            });

            ButtonLogout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    getter = new httpGetter();
                    getter.execute("Logout", currentPlayerID);
                    stopService(service);
                    firebaseAuth.signOut();
                    finish();
                    startActivity(new Intent(getApplicationContext(), LoginActivity.class));
                }
            });
        }





    }

    public static void SendToken(String token) {
        httpGetter sender = new httpGetter();
        sender.execute("UpdateFirebaseToken", getPlayerID(), token);
        try {
            String res = sender.get();
            Log.d("INFORMATION", "Server on token :" + res);
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }
    }

   public static void startTimer(long tls, long rec) {
        TimeLeftInMillis = tls * 1000;

        if (cdt != null) {
            cdt.cancel();
            cdt = null;
        }

        cdt = new CountDownTimer(TimeLeftInMillis, rec) {
            @Override
            public void onTick(long millisUntilFinished) {
                TimeLeftInMillis = millisUntilFinished;
                TimeLeftInSecs = TimeLeftInMillis / 1000;
                upDateCountDownText();
            }

            @Override
            public void onFinish() {

            }


        };

        cdt.start();
    }


    public static void startCountUpTimer(long tls, long rec) {
        TimeLeftInMillis = tls * 1000;
        final long wholetime = tls*1000;

        if (cdt != null) {
            cdt.cancel();
            cdt = null;
        }

        cdt = new CountDownTimer(TimeLeftInMillis, rec) {
            @Override
            public void onTick(long millisUntilFinished) {
                TimeLeftInMillis = wholetime + (wholetime - millisUntilFinished)*10;
                TimeLeftInSecs = TimeLeftInMillis / 1000;
                upDateCountDownText();
            }

            @Override
            public void onFinish() {

            }


        };

        cdt.start();
    }


    private static void upDateCountDownText() {

        int hours = (int) (TimeLeftInSecs / 3600);
        int minutes = (int) ((TimeLeftInSecs % 3600) / 60);
        int seconds = (int) ((TimeLeftInSecs % 3600) % 60);
        String timeLeft = String.format("%02d:%02d:%02d", hours, minutes, seconds);
        TextViewCountdown.setText(timeLeft);
    }

    public static String getPlayerID() {
        return currentPlayerID;
    }



    public static void dead(boolean state) {

        if (state) {
            TextViewCountdown.setVisibility(View.INVISIBLE);
            Hr.setVisibility(View.INVISIBLE);
            Mn.setVisibility(View.INVISIBLE);
            Sec.setVisibility(View.INVISIBLE);
            TextViewDead.setVisibility(View.VISIBLE);
        } else {
            TextViewDead.setVisibility(View.INVISIBLE);
            TextViewCountdown.setVisibility(View.VISIBLE);
            Hr.setVisibility(View.VISIBLE);
            Mn.setVisibility(View.VISIBLE);
            Sec.setVisibility(View.VISIBLE);

        }
    }

    private String getTime(String line) {
        //  String line = "[{Time,true}]";
        int commaNbr = 0 ;
        int dpp = 0;
        ArrayList<String> list = new ArrayList<String>();

        for (int i = 0; i < line.length(); i++) {
            char itr = line.charAt(i);
            if (itr == ':') {
                commaNbr++;

            }
        }

        int commaPos[] = new int[commaNbr];
        int doublePointsPos[] = new int[dpp];
        int j = 0;
        int z = 0;
        for (int i = 0; i < line.length(); i++) {
            char itr = line.charAt(i);
            if (itr == ':') {
                commaPos[j] = i;
                j++;

            }
        }

        int k = 0 ;


        String sub = line.substring(1,commaPos[0] );
        return sub ;
    }


    private void updateTitleIcon(){
        if(Title.substring(1,Title.length()-1).equals("Neo From The Matrix"))
            TitleIcon.setImageResource(R.drawable.neo);
            else if (Title.substring(1,Title.length()-1).equals("Molasses In Winter"))
            TitleIcon.setImageResource(R.drawable.molasses);
                else if (Title.substring(1,Title.length()-1).equals("2 Fast 4 U"))
            TitleIcon.setImageResource(R.drawable.fast);
                      else if (Title.substring(1,Title.length()-1).equals("Average Joe"))
            TitleIcon.setImageResource(R.drawable.avgjoe);
        else if (Title.substring(1,Title.length()-1).equals("Older Than The Universe"))
            TitleIcon.setImageResource(R.drawable.universe);



    }

}