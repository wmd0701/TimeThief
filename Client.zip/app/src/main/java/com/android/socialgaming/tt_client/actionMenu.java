package com.android.socialgaming.tt_client;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.android.socialgaming.tt_client.util.httpGetter;

import java.util.concurrent.ExecutionException;

import static com.android.socialgaming.tt_client.R.id.nickname;

public class actionMenu extends AppCompatActivity implements View.OnClickListener {

    private Button Stealbutton;
    private Button Add;
    private Button Share;
    private String nickname;
    private httpGetter addFriend ;
    private String httpGetterResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actionmenu);
        Stealbutton = (Button) findViewById(R.id.steal_button);
        Stealbutton.setOnClickListener(this);
        Add = (Button) findViewById(R.id.add_button);
        Add.setOnClickListener(this);
        Share = (Button) findViewById(R.id.share_button);
        Share.setOnClickListener(this);

        Intent intent = getIntent() ;
        nickname = intent.getStringExtra("nickname");

        httpGetter getter = new httpGetter();
        getter.execute("GetFriends", MenuActivity.getPlayerID());
        try {
            httpGetterResult = getter.get();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }
        if(!httpGetterResult.contains(""+nickname)){
            Share.setVisibility(View.INVISIBLE);
            Share.setClickable(false);
        }else{
            Stealbutton.setVisibility(View.INVISIBLE);
            Stealbutton.setClickable(false);
        }


      /*  @SuppressLint("WrongViewCast") Button return_button =(Button)findViewById(R.id.return_button);
        return_button.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext() ,MenuActivity.class);
                startActivity(intent) ;
            }
        });*/
    }


    @Override
    public void onClick(View v) {
        if(v == Stealbutton){
            finish();
            Intent intent = new Intent(getApplicationContext() , StealActivity.class) ;
            intent.putExtra("target",nickname);
            startActivity(intent);
        }

        if(v == Add){
            addFriend = new httpGetter();
            addFriend.execute("AddFriend", MenuActivity.getPlayerID(), nickname) ;
            try {
                httpGetterResult = addFriend.get();
            } catch (InterruptedException e) {
                e.printStackTrace();
            } catch (ExecutionException e) {
                e.printStackTrace();
            }
        }

        if(v == Share){
            Intent intent = new Intent(getApplicationContext() , ShareActivity.class) ;
            intent.putExtra("target",nickname);
            startActivity(intent);
        }
    }
}
