package com.android.socialgaming.tt_client;

import android.util.Log;

import com.android.socialgaming.tt_client.MenuActivity;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.FirebaseInstanceIdService;

import java.util.concurrent.ExecutionException;

public class FirebaseIdManager extends FirebaseInstanceIdService {
    @Override
    public void onTokenRefresh() {
        String refreshedToken = FirebaseInstanceId.getInstance().getToken();
        Log.d("INFORMATION", "Refreshed token: "+refreshedToken);
        // Send to server
        MenuActivity.SendToken(refreshedToken);
    }
}
