package com.android.socialgaming.tt_client;

import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import com.android.socialgaming.tt_client.util.httpGetter;

public class DefendActivity extends AppCompatActivity implements View.OnClickListener{

    private TextView Name;
    private Button Catch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_defend);
        Catch = findViewById(R.id.catchThief);
        Catch.setOnClickListener(this);
        Name = findViewById(R.id.tryhard);
        Name.setText(FirebaseListener.target);
        determination();
    }


    public void determination(){
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            public void run() {
                finish();
            }
        }, 8500);
    }

    @Override
    public void onClick(View v) {
        if(Catch == v){
            httpGetter getter = new httpGetter();
            getter.execute("SendDefendWarning",MenuActivity.getPlayerID(), FirebaseListener.target);
            finish();
        }
    }
}
