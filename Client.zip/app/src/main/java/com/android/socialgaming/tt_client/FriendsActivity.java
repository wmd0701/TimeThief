package com.android.socialgaming.tt_client;

import android.media.Image;
import android.os.Bundle;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.android.socialgaming.tt_client.util.httpGetter;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

public class FriendsActivity extends AppCompatActivity {
    private String PlayerID = "";
    private httpGetter getter;
    private String result = "";
    private TextView TextViewFriends;
    private ImageView RedDot1;
    private ImageView RedDot2;
    private ImageView RedDot3;
    private ImageView RedDot4;
    private ImageView RedDot5;
    private ImageView GreenDot1;
    private ImageView GreenDot2;
    private ImageView GreenDot3;
    private ImageView GreenDot4;
    private ImageView GreenDot5;
    private ImageView Remove1;
    private ImageView Remove2;
    private ImageView Remove3;
    private ImageView Remove4;
    private ImageView Remove5;
    private ImageView[] Red = new ImageView[5];
    private ImageView[] Green = new ImageView[5];
    private ImageView[] Remove = new ImageView[5];
    public  static int nbFriends = 0;
    private static ArrayList<String> Friends = new ArrayList<String>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_friends);
        TextViewFriends = findViewById(R.id.text_view_friends);
        TextViewFriends.setText("");
        PlayerID = MenuActivity.getPlayerID();
        initialiseViews();
        updateFriendList();
       updateImagesList();

        //repeat for other remove buttons
        Remove1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                     if(Remove1.getVisibility()==View.VISIBLE)
                     {getter = new httpGetter();
                     //delete friend methode aufrufen
                     getter.execute("RemoveFriend", PlayerID, Friends.get(0));
                     disableImages();
                     Friends.remove(0);
                     updateFriendList();
                     updateImagesList();

                     }
                }
                                   }
        );

        Remove2.setOnClickListener(new View.OnClickListener() {
                                       @Override
                                       public void onClick(View v) {
                                           if(Remove2.getVisibility()==View.VISIBLE)
                                           {getter = new httpGetter();
                                               //delete friend methode aufrufen
                                               getter.execute("RemoveFriend", PlayerID, Friends.get(1));
                                               disableImages();
                                               Friends.remove(1);
                                               updateFriendList();
                                               updateImagesList();

                                           }
                                       }
                                   }
        );
        Remove3.setOnClickListener(new View.OnClickListener() {
                                       @Override
                                       public void onClick(View v) {
                                           if(Remove3.getVisibility()==View.VISIBLE)
                                           {getter = new httpGetter();
                                               //delete friend methode aufrufen
                                               getter.execute("RemoveFriend", PlayerID, Friends.get(2));
                                               disableImages();
                                               Friends.remove(2);
                                               updateFriendList();
                                               updateImagesList();

                                           }
                                       }
                                   }
        );

        Remove4.setOnClickListener(new View.OnClickListener() {
                                       @Override
                                       public void onClick(View v) {
                                           if(Remove4.getVisibility()==View.VISIBLE)
                                           {getter = new httpGetter();
                                               //delete friend methode aufrufen
                                               getter.execute("RemoveFriend", PlayerID, Friends.get(3));
                                               disableImages();
                                               Friends.remove(3);
                                               updateFriendList();
                                               updateImagesList();

                                           }
                                       }
                                   }
        );

        Remove5.setOnClickListener(new View.OnClickListener() {
                                       @Override
                                       public void onClick(View v) {
                                           if(Remove5.getVisibility()==View.VISIBLE)
                                           {getter = new httpGetter();
                                               //delete friend methode aufrufen
                                               getter.execute("RemoveFriend", PlayerID, Friends.get(4));
                                               disableImages();
                                               Friends.remove(4);
                                               updateFriendList();
                                               updateImagesList();


                                           }
                                       }
                                   }
        );
    }

//Printing the list of friends
    private void SetFriendsList() {

        TextViewFriends.setText("");

        if (Friends==null)
            TextViewFriends.setText("You don't have any friend for the moment!");

        else {
            for (int i = 0; i < nbFriends; i++) {
                TextViewFriends.append(Friends.get(i));
                TextViewFriends.append("\n");
            }
        }
    }

    //converts the output of the server method into an array with all friends
    private ArrayList<String> GetList(String buffer) {
        List<Integer> KommaPos = new ArrayList<Integer>();
        int begin = 1;
        int last = buffer.length() - 1;
        int j = 0;
        for (int i = 0; i < buffer.length(); i++) {
            if (buffer.charAt(i) == ',')
                KommaPos.add(i);
        }


      //  String[] list = new String[KommaPos.size() + 1];

        ArrayList<String> list = new ArrayList<String>();
        //0 friend
        if(buffer.charAt(0)=='[' && buffer.charAt(1)==']'){
            nbFriends = 0;
            return null;
        }

        //1 friend
        if (KommaPos.size() == 0) {
             list.add(buffer.substring(begin, last));
            return list;
        }

        while (j <= KommaPos.size()) {
            list.add(buffer.substring(begin, KommaPos.get(j)));
            begin = KommaPos.get(j) + 1;
            j++;
            if (j >= KommaPos.size()) {
                list.add(buffer.substring(begin, result.length() - 1));
                break;
            }
        }

        return list;
    }

    //initialisation of dots and trash bins
    private void initialiseViews() {
        RedDot1 = (ImageView) findViewById(R.id.RedDot1);
        RedDot2 = (ImageView) findViewById(R.id.RedDot2);
        RedDot3 = (ImageView) findViewById(R.id.RedDot3);
        RedDot4 = (ImageView) findViewById(R.id.RedDot4);
        RedDot5 = (ImageView) findViewById(R.id.RedDot5);
        GreenDot1 = (ImageView) findViewById(R.id.GreenDot1);
        GreenDot2 = (ImageView) findViewById(R.id.GreenDot2);
        GreenDot3 = (ImageView) findViewById(R.id.GreenDot3);
        GreenDot4 = (ImageView) findViewById(R.id.GreenDot4);
        GreenDot5 = (ImageView) findViewById(R.id.GreenDot5);
        Remove1 = (ImageView) findViewById(R.id.Remove1);
        Remove2 = (ImageView) findViewById(R.id.Remove2);
        Remove3 = (ImageView) findViewById(R.id.Remove3);
        Remove4 = (ImageView) findViewById(R.id.Remove4);
        Remove5 = (ImageView) findViewById(R.id.Remove5);

        Red[0] = RedDot1;
        Red[1] = RedDot2;
        Red[2] = RedDot3;
        Red[3] = RedDot4;
        Red[4] = RedDot5;
        Green[0] = GreenDot1;
        Green[1] = GreenDot2;
        Green[2] = GreenDot3;
        Green[3] = GreenDot4;
        Green[4] = GreenDot5;
        Remove[0] = Remove1;
        Remove[1] = Remove2;
        Remove[2] = Remove3;
        Remove[3] = Remove4;
        Remove[4] = Remove5;

        disableImages();


    }

    //disables all the imageviews
    private void disableImages(){
        for (int i = 0; i < 5; i++) {
            Red[i].setVisibility(View.INVISIBLE);
            Green[i].setVisibility(View.INVISIBLE);
            Remove[i].setVisibility(View.INVISIBLE);
        }
    }

    //activates the dot and trash bin images depending on the number of friends in the list
    private void updateImagesList() {


        for (int i = 0; i < nbFriends; i++) {
            getter = new httpGetter();
            Remove[i].setVisibility(View.VISIBLE);
            //change function name

            getter.execute("GetActiveOfFriend", PlayerID, Friends.get(i));

            try {
                result = getter.get();
            } catch (InterruptedException e) {
                e.printStackTrace();
            } catch (ExecutionException e) {
                e.printStackTrace();
            }


            if (result.equals("true"))
                Green[i].setVisibility(View.VISIBLE);
            else  if(result.equals("false")) {
                Red[i].setVisibility(View.VISIBLE);
            }
        }


    }

  //updates the list of Friends from the server
    private void updateFriendList(){
        getter = new httpGetter();
        getter.execute("GetFriends", PlayerID);

        try {
            result = getter.get();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }

        Friends= GetList(result);

        if(Friends!=null)
            nbFriends = GetList(result).size();

        SetFriendsList();
    }


    public static ArrayList<String> getFriends(){
        return Friends;
    }
}
