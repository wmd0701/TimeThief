package com.android.socialgaming.tt_client.util;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.util.Log;
import android.view.Menu;
import android.widget.Toast;

import com.android.socialgaming.tt_client.MapsActivity;
import com.android.socialgaming.tt_client.MenuActivity;
import com.google.android.gms.maps.model.Circle;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;

import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

public class Service extends android.app.Service {
    private httpGetter updateLocation;
    private httpGetter getTimeHoles;
    private httpGetter getActiveUsers ;
    private String activeUsersJSON ;
    private String timeHolesJSON ;
    private String result;
    public static ArrayList<String> listActiveUsers ;
    public static ArrayList<String> listTimeHoles;
    public static Boolean inTimeHoleRange = false;
    public static Boolean dead = false;
    private Boolean inTimeHoleRangeNew = false;
    private CircleOptions circleOptions ;
    public static long currentPlayerTime = 0;
    public static LocationManager locationManager;
    private LocationListener locationListener;
    public static LatLng latLng = new LatLng(0, 0);
    public Context context = this;

    public void onCreate() {
        //  handler = new Handler();
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }

        locationListener = new LocationListener() {

            @Override
            public void onLocationChanged(Location location) {
                //TODO: this is where all the updates wil be done

                latLng = new LatLng(location.getLongitude(), location.getLatitude());
                //get the currentPlayer location from the server
                updateLocation = new httpGetter();
                updateLocation.execute("Update", MenuActivity.getPlayerID(), "" + latLng.longitude, "" + latLng.latitude);
                try {
                    result = updateLocation.get();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                } catch (ExecutionException e) {
                    e.printStackTrace();
                }

                currentPlayerTime = Long.parseLong(getTime(result));


                // get the other players location from the server
                getActiveUsers = new httpGetter();
                getActiveUsers.execute("GetActiveUsers", MenuActivity.currentPlayerID ,"100000");
                try {
                    activeUsersJSON = getActiveUsers.get() ;

                } catch (InterruptedException e) {
                    e.printStackTrace();
                } catch (ExecutionException e) {
                    e.printStackTrace();
                }
                listActiveUsers = GetList(activeUsersJSON);

                //get the location of time Holes from the server
                getTimeHoles = new httpGetter() ;
                getTimeHoles.execute("GetTimeHoles",MenuActivity.currentPlayerID ,"100000");
                try {
                    timeHolesJSON = getTimeHoles.get() ;
                } catch (InterruptedException e) {
                    e.printStackTrace();
                } catch (ExecutionException e) {
                    e.printStackTrace();
                }
                listTimeHoles = GetTimeHolesList(timeHolesJSON) ;

               // Toast.makeText(context, " Time : " + getTime(result) + " in Range : " + getTimeHoleState(result) + " inTimeHoleRange : " + inTimeHoleRange, Toast.LENGTH_LONG).show();
                //check if the player in the Time Hole range
                if (getTimeHoleState(result).equals("true")) {
                    inTimeHoleRangeNew = true;
                } else {
                    inTimeHoleRangeNew = false;
                }

              if(!inTimeHoleRange && inTimeHoleRangeNew)
                MenuActivity.startCountUpTimer(Long.parseLong(getTime(result)), 1000);
              else if(inTimeHoleRange && !inTimeHoleRangeNew)
                  MenuActivity.startTimer(Long.parseLong(getTime(result)), 1000);
              else if(inTimeHoleRange && inTimeHoleRangeNew)
                  MenuActivity.startCountUpTimer(Long.parseLong(getTime(result)), 1000);


              inTimeHoleRange = inTimeHoleRangeNew;

              if(Long.parseLong(getTime(result))==0)
                  dead=true;
              else
              dead = false;


              MenuActivity.dead(dead);






            }

            @Override
            public void onStatusChanged(String s, int i, Bundle bundle) {

            }

            @Override
            public void onProviderEnabled(String s) {

            }

            @Override
            public void onProviderDisabled(String s) {

            }
        };
        updater();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private void updater() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        locationManager.requestLocationUpdates("gps", 3000, 0, locationListener);
    }
@Override
    public void onDestroy(){
        Toast.makeText(this, "Service stopped", Toast.LENGTH_LONG).show();
        locationListener = null;
        super.onDestroy();
    }

    @Override
    public void onStart(Intent intent, int startid){
        Toast.makeText(this, "Service started", Toast.LENGTH_LONG).show();
    }

    public CircleOptions createCircle(LatLng currentLatLng , int radius , int color , boolean clickable) {
        CircleOptions circleOptions  = new CircleOptions();
        circleOptions.center(currentLatLng) ;
        circleOptions.fillColor(color) ;
        circleOptions.radius(radius);
        circleOptions.clickable(clickable);
        return circleOptions ;
    }

    private ArrayList<String> GetTimeHolesList(String line)    {
        int commaNbr = 0 ;
        int dpp = 0;
        ArrayList<String> list = new ArrayList<String>();
        if ( line.equals("[]")) {
            return null ;
        }
        else {
            for (int i = 0; i < line.length(); i++) {
                char itr = line.charAt(i);
                if (itr == ',') {
                    commaNbr++;

                } else if (itr == ':') {
                    dpp++;
                }
            }

            int commaPos[] = new int[commaNbr];
            int doublePointsPos[] = new int[dpp];
            int j = 0;
            int z = 0;
            for (int i = 0; i < line.length(); i++) {
                char itr = line.charAt(i);
                if (itr == ',') {
                    commaPos[j] = i;
                    j++;

                } else if (itr == ':') {
                    doublePointsPos[z] = i;
                    z++;
                }
            }

            int k = 0;

            for (int i = 0; i < dpp - 1; i++) {

                String sub = line.substring(doublePointsPos[i] + 1, commaPos[k]);
                list.add(sub);
                i++;
                if (k < commaNbr - 1) {
                    k++;
                    sub = line.substring(doublePointsPos[i] + 1, commaPos[k] - 1);
                    list.add(sub);
                    k++;
                }
            }

            String sub = line.substring(doublePointsPos[dpp - 1] + 1, line.length() - 2);
            list.add(sub);
            return list;
        }
    }
    private String getTimeHoleState(String line) {
      //  String line = "[{Time,true}]";
        int commaNbr = 0 ;
        ArrayList<String> list = new ArrayList<String>();

        for (int i = 0; i < line.length(); i++) {
            char itr = line.charAt(i);
            if (itr == ':') {
                commaNbr++;
            }
        }

        int commaPos[] = new int[commaNbr];
        int j = 0;
        int z = 0;
        for (int i = 0; i < line.length(); i++) {
            char itr = line.charAt(i);
            if (itr == ':') {
                commaPos[j] = i;
                j++;

            }
        }

        int k = 0 ;


        String sub = line.substring(commaPos[0]+1,line.length()-1);
        return sub ;
    }

    // get the information from the JsonObject
    private ArrayList<String> GetList(String line){
        // String line = "{Test1:{Longitude:100,Altitude:150},Test2:{Longitude:200,Altitude:250},Test3:{Longitude:300,Latitude:350},Test4:{Longitude:400,Latitude:450},Test5:{Longitude:400,Latitude:450},Test6:{Longitude:400,Latitude:450},Test6:{Longitude:400,Latitude:450},Test6:{Longitude:400,Latitude:450},Test6:{Longitude:400,Latitude:450},Test6:{Longitude:400,Latitude:450},Test6:{Longitude:400,Latitude:450},Test6:{Longitude:400,Latitude:450},Test6:{Longitude:400,Latitude:450},Test6:{Longitude:400,Latitude:450},Test6:{Longitude:400,Latitude:450},Test6:{Longitude:400,Latitude:450},Test6:{Longitude:400,Latitude:450},Test6:{Longitude:400,Latitude:450},Test6:{Longitude:400,Latitude:450},Test6:{Longitude:400,Latitude:450},Test6:{Longitude:400,Latitude:450},Test6:{Longitude:400,Latitude:450},Test6:{Longitude:400,Latitude:450}";
        if ( line.equals("{}")){
            return null ;
        }
        else {
            int commaNbr = 0;
            int dpp = 0;
            ArrayList<String> list = new ArrayList<String>();

            for (int i = 0; i < line.length(); i++) {
                char itr = line.charAt(i);
                if (itr == ',') {
                    commaNbr++;

                } else if (itr == ':') {
                    dpp++;
                }
            }


            int commaPos[] = new int[commaNbr];
            int doublePointsPos[] = new int[dpp];
            int j = 0;
            int z = 0;
            for (int i = 0; i < line.length(); i++) {
                char itr = line.charAt(i);
                if (itr == ',') {
                    commaPos[j] = i;
                    j++;

                } else if (itr == ':') {
                    doublePointsPos[z] = i + 1;
                    z++;
                }
            }


            String sub = line.substring(1, doublePointsPos[0] - 1);
            list.add(sub);


            int k = 0;
            for (int i = 1; i < dpp - 2; i += 3) {
                String sub1 = line.substring(doublePointsPos[i], commaPos[k]);
                String sub2 = line.substring(doublePointsPos[i + 1], commaPos[k + 1] - 1);
                String sub3 = line.substring(commaPos[k + 1] + 1, doublePointsPos[i + 2] - 1);
                k += 2;
                list.add(sub1);
                list.add(sub2);
                list.add(sub3);

            }

            sub = line.substring(doublePointsPos[doublePointsPos.length - 2], commaPos[commaPos.length - 1]);
            list.add(sub);
            sub = line.substring(doublePointsPos[doublePointsPos.length - 1], line.length() - 2);
            list.add(sub);


            return list;
        }
    }
    private String getTime(String line) {
        //  String line = "[{Time,true}]";
        int commaNbr = 0 ;
        for (int i = 0; i < line.length(); i++) {
            char itr = line.charAt(i);
            if (itr == ':') {
                commaNbr++;

            }
        }

        int commaPos[] = new int[commaNbr];
        int j = 0;
        for (int i = 0; i < line.length(); i++) {
            char itr = line.charAt(i);
            if (itr == ':') {
                commaPos[j] = i;
                j++;

            }
        }

        String sub = line.substring(1,commaPos[0] );
        return sub ;
    }
}


