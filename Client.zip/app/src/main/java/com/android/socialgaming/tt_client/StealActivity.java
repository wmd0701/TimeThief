package com.android.socialgaming.tt_client;

import com.android.socialgaming.tt_client.util.httpGetter;
import com.android.socialgaming.tt_client.util.httpPoster;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.SensorManager;
import android.os.CountDownTimer;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Map;
import java.util.concurrent.ExecutionException;

import com.squareup.seismic.ShakeDetector;

import org.w3c.dom.Text;

public class StealActivity extends AppCompatActivity implements ShakeDetector.Listener, View.OnClickListener{

        private TextView text;
        private TextView counter;
        private httpGetter getter;
        private Button end_steal;
        private String target;
        private String myID;
        private FirebaseUser me;
        private FirebaseAuth firebaseAuth;
        private long timestolen;
        private boolean shaken = false;
        private long TimeLeftInMillis = 10100;
        private ShakeDetector Detect;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_steal);
        LocalBroadcastManager.getInstance(this).registerReceiver(mHandler, new IntentFilter("FCM_Message"));

        Intent intent = getIntent() ;
        target = intent.getStringExtra("target");
        firebaseAuth = FirebaseAuth.getInstance();
        if(firebaseAuth.getCurrentUser() == null){
            finish();
            startActivity(new Intent(this, LoginActivity.class));
        }
        me = firebaseAuth.getCurrentUser();
        myID = me.getUid();
        timestolen = 0;

        end_steal = (Button) findViewById(R.id.end_steal);
        text = (TextView) findViewById(R.id.shake_text);
        counter = (TextView) findViewById(R.id.counterup);
        end_steal.setOnClickListener(this);
        SensorManager sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        Detect = new ShakeDetector(this);
        Detect.start(sensorManager);
    }

    public BroadcastReceiver mHandler = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            Toast toast = Toast.makeText(context,"You got cought!!! HAHA", Toast.LENGTH_LONG);
            toast.show();
            endSteal("true");
            finish();
            startActivity(new Intent(getApplicationContext(), MenuActivity.class));
        }
    };

    @Override
    public void hearShake(){
        startSteal();
    }

    public void startSteal(){

        if(!shaken){
            shaken = true;
            text.setText("Stealing..");
            getter = new httpGetter();
            getter.execute("BeginSteal", myID, target);
            startTimer();
        }

    }

    public void endSteal(String defend){
        getter = new httpGetter();
        getter.execute("EndSteal", myID, target, defend);
        text.setText("Shake your Device to steal");
        shaken = false;
        TimeLeftInMillis = 10100;
    }

    public void updatetext(){
            timestolen += 10;
            int hours = (int) (timestolen / 3600);
            int minutes = (int) ((timestolen % 3600) / 60);
            int seconds = (int) ((timestolen % 3600) % 60);
            String newtime = String.format("%02d:%02d:%02d", hours, minutes, seconds);
            counter.setText(newtime);
    }

    private void startTimer() {
        CountDownTimer cdt = new CountDownTimer(TimeLeftInMillis, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                TimeLeftInMillis = millisUntilFinished;
                updatetext();
            }
            @Override
            public void onFinish() {
                endSteal("false");
            }
        }.start();
    }

    public void onClick(View view){
        if(view == end_steal){
            endSteal("false");
            finish();
            startActivity(new Intent(getApplicationContext(), MenuActivity.class));
        }
    }
}
